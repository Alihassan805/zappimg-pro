/**
 * Post-build step:  vite build && tsx scripts/prerender.ts
 * Creates a real static HTML page for every tool (dist/background-remover/index.html ...) with its own
 * <title>, meta description, canonical, Open Graph tags, JSON-LD (WebApplication + FAQ + Breadcrumb)
 * and crawlable text content. Also writes dist/sitemap.xml.
 * The React app then takes over (same JS bundle), so users still get the full interactive tool.
 */
import fs from 'node:fs';
import path from 'node:path';
import { TOOL_SEO, SITE_URL } from '../src/seo';

const SITE = (process.env.SITE_URL || SITE_URL).replace(/\/$/, '');
const dist = path.resolve('dist');
const template = fs.readFileSync(path.join(dist, 'index.html'), 'utf8');

const esc = (v: string) => v.replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;').replace(/>/g, '&gt;');

function setTag(html: string, re: RegExp, replacement: string): string {
  return re.test(html) ? html.replace(re, replacement) : html;
}

for (const t of TOOL_SEO) {
  const url = `${SITE}/${t.slug}/`;
  let html = template;
  html = setTag(html, /<title>[\s\S]*?<\/title>/, `<title>${esc(t.title)}</title>`);
  html = setTag(html, /<meta name="description" content="[^"]*" \/>/, `<meta name="description" content="${esc(t.description)}" />`);
  html = setTag(html, /<meta name="keywords" content="[^"]*" \/>/, `<meta name="keywords" content="${esc(t.keywords)}" />`);
  html = setTag(html, /<link rel="canonical" href="[^"]*" \/>/, `<link rel="canonical" href="${url}" />`);
  html = html.replace(/<link rel="alternate" hreflang="[^"]*" href="[^"]*" \/>/g, (m) => m.replace(/href="[^"]*"/, `href="${url}"`));
  html = html.replace(/<meta property="og:url" content="[^"]*" \/>/, `<meta property="og:url" content="${url}" />`);
  html = html.replace(/<meta name="twitter:url" content="[^"]*" \/>/, `<meta name="twitter:url" content="${url}" />`);
  html = html.replace(/<meta property="og:title" content="[^"]*" \/>/, `<meta property="og:title" content="${esc(t.title)}" />`);
  html = html.replace(/<meta name="twitter:title" content="[^"]*" \/>/, `<meta name="twitter:title" content="${esc(t.title)}" />`);
  html = html.replace(/<meta property="og:description" content="[^"]*" \/>/, `<meta property="og:description" content="${esc(t.description)}" />`);
  html = html.replace(/<meta name="twitter:description" content="[^"]*" \/>/, `<meta name="twitter:description" content="${esc(t.description)}" />`);

  // Replace the generic JSON-LD blocks with tool-specific ones
  html = html.replace(/<script type="application\/ld\+json">[\s\S]*?<\/script>\s*/g, '');
  const ld = [
    {
      '@context': 'https://schema.org',
      '@type': 'WebApplication',
      name: `ZappImg Pro – ${t.name}`,
      url,
      description: t.description,
      applicationCategory: 'MultimediaApplication',
      operatingSystem: 'Any',
      offers: { '@type': 'Offer', price: '0', priceCurrency: 'USD' },
    },
    {
      '@context': 'https://schema.org',
      '@type': 'BreadcrumbList',
      itemListElement: [
        { '@type': 'ListItem', position: 1, name: 'Home', item: `${SITE}/` },
        { '@type': 'ListItem', position: 2, name: t.name, item: url },
      ],
    },
    {
      '@context': 'https://schema.org',
      '@type': 'FAQPage',
      mainEntity: t.faqs.map((f) => ({ '@type': 'Question', name: f.q, acceptedAnswer: { '@type': 'Answer', text: f.a } })),
    },
    {
      '@context': 'https://schema.org',
      '@type': 'HowTo',
      name: t.h1,
      step: t.steps.map((s, i) => ({ '@type': 'HowToStep', position: i + 1, text: s })),
    },
  ]
    .map((o) => `<script type="application/ld+json">${JSON.stringify(o)}</script>`)
    .join('\n    ');
  html = html.replace('</head>', `    ${ld}\n  </head>`);

  // Crawlable content inside #root (React replaces it as soon as the app mounts)
  const nav = TOOL_SEO.map((x) => `<li><a href="/${x.slug}/">${esc(x.name)}</a></li>`).join('');
  const body = `<main style="max-width:860px;margin:0 auto;padding:32px 20px;font-family:system-ui,sans-serif;color:#4B5160">
      <h1 style="color:#14171F;font-size:32px;line-height:1.2">${esc(t.h1)}</h1>
      <p style="font-size:17px;line-height:1.6">${esc(t.intro)}</p>
      <h2 style="color:#14171F">How it works</h2>
      <ol>${t.steps.map((x) => `<li>${esc(x)}</li>`).join('')}</ol>
      <h2 style="color:#14171F">FAQ</h2>
      ${t.faqs.map((f) => `<h3>${esc(f.q)}</h3><p>${esc(f.a)}</p>`).join('')}
      <h2 style="color:#14171F">More free image tools</h2>
      <ul>${nav}</ul>
    </main>`;
  html = html.replace('<div id="root"></div>', `<div id="root">${body}</div>`);

  const outDir = path.join(dist, t.slug);
  fs.mkdirSync(outDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, 'index.html'), html);
}

// Sitemap
const today = new Date().toISOString().slice(0, 10);
const urls = [{ loc: `${SITE}/`, pr: '1.0' }, ...TOOL_SEO.map((t) => ({ loc: `${SITE}/${t.slug}/`, pr: t.id === 'bgremove' || t.id === 'resize' ? '0.9' : '0.8' }))];
const legal = ['privacy', 'terms', 'cookies', 'security'];
const sitemap =
  `<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n` +
  urls.map((u) => `  <url><loc>${u.loc}</loc><lastmod>${today}</lastmod><changefreq>weekly</changefreq><priority>${u.pr}</priority></url>`).join('\n') +
  `\n</urlset>\n`;
fs.writeFileSync(path.join(dist, 'sitemap.xml'), sitemap);
console.log(`Prerendered ${TOOL_SEO.length} tool pages + sitemap.xml (${urls.length} URLs, legal hash routes excluded: ${legal.join(', ')})`);

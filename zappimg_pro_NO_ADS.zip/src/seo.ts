/**
 * Single source of truth for per-tool SEO landing pages.
 * Used by:  (1) the app (title / meta / URL sync when a tool is selected)
 *           (2) scripts/prerender.ts (generates real static HTML pages at build time)
 */
export const SITE_URL = 'https://zappimg.pro';

export type ToolSlugId =
  | 'resize' | 'convert' | 'img2pdf' | 'pdf2img' | 'bgremove'
  | 'crop' | 'favicon' | 'passport' | 'metadata' | 'base64';

export interface ToolSeo {
  id: ToolSlugId;
  slug: string;
  name: string;
  title: string;
  description: string;
  keywords: string;
  h1: string;
  intro: string;
  steps: string[];
  faqs: { q: string; a: string }[];
}

export const TOOL_SEO: ToolSeo[] = [
  {
    id: 'resize',
    slug: 'image-resizer-compressor',
    name: 'Resize & Compress',
    title: 'Image Resizer & Compressor Online – Compress to 100 KB, Free | ZappImg Pro',
    description: 'Resize and compress images online for free. Bulk resize up to 100 photos, compress JPG, PNG and WebP to under 100 KB, 110+ presets for Instagram, YouTube and more. 100% private.',
    keywords: 'image resizer, compress image online, reduce image size, compress image to 100kb, bulk image resizer, resize image for instagram, image compressor',
    h1: 'Free Image Resizer & Compressor',
    intro: 'Resize and compress up to 100 photos at once. Pick one of 110+ presets (Instagram, YouTube, LinkedIn, passport and more) or set a target file size like 100 KB. Everything runs in your browser, so your photos stay private.',
    steps: ['Drop your photos into the tray.', 'Choose a preset or type your own width, height and target size.', 'Click Execute and download everything as one ZIP.'],
    faqs: [
      { q: 'How do I compress an image to under 100 KB?', a: 'Open Resize & Compress, enter 100 as the target size in KB and click Execute. The engine searches for the highest quality that still fits the limit.' },
      { q: 'Can I resize many photos at once?', a: 'Yes. Add up to 100 photos, choose one size and every photo is resized in a single click.' },
    ],
  },
  {
    id: 'convert',
    slug: 'image-converter',
    name: 'Convert Format',
    title: 'Image Converter – PNG to WebP, HEIC to JPG, JPG to PNG Online | ZappImg Pro',
    description: 'Convert images between JPG, PNG, WebP, AVIF and HEIC online for free. Batch convert iPhone HEIC photos to JPG without losing quality. No upload, no signup.',
    keywords: 'image converter, png to webp, heic to jpg, jpg to png, convert image format online, webp to jpg, avif converter',
    h1: 'Free Image Format Converter',
    intro: 'Convert PNG, JPG, WebP, AVIF and HEIC in bulk. Perfect for turning iPhone HEIC photos into JPG or shrinking PNG files into modern WebP for faster websites.',
    steps: ['Add your images.', 'Pick the target format and quality.', 'Convert and download the ZIP.'],
    faqs: [
      { q: 'How do I convert PNG to WebP?', a: 'Select Convert Format, choose WebP and click Execute. WebP is typically 25–35% smaller than PNG with the same visual quality.' },
      { q: 'Can I convert HEIC photos from my iPhone?', a: 'Yes, HEIC/HEIF files are decoded locally and exported as JPG, PNG or WebP.' },
    ],
  },
  {
    id: 'img2pdf',
    slug: 'images-to-pdf',
    name: 'Images to PDF',
    title: 'Images to PDF – Merge JPG & PNG into One PDF Online Free | ZappImg Pro',
    description: 'Combine multiple JPG or PNG images into a single PDF online. Choose A4 or US Letter, set margins and page order. Free, private, no upload.',
    keywords: 'images to pdf, jpg to pdf, png to pdf, merge images into pdf, combine photos into pdf, photo to pdf converter',
    h1: 'Merge Images into One PDF',
    intro: 'Turn photos, scans and screenshots into a clean multi-page PDF. Choose A4, US Letter or fit-to-image, set margins and orientation, then download instantly.',
    steps: ['Add your images in the order you want.', 'Choose page size, orientation and margin.', 'Download your PDF.'],
    faqs: [
      { q: 'How do I turn several JPG files into one PDF?', a: 'Drop the photos in the tray, select Images to PDF, choose a page size and click Execute.' },
      { q: 'Is there a page limit?', a: 'Guests can merge up to 50 pages and free members up to 200 pages per PDF.' },
    ],
  },
  {
    id: 'pdf2img',
    slug: 'pdf-to-image',
    name: 'PDF to Images',
    title: 'PDF to JPG & PNG Converter – Extract PDF Pages as Images | ZappImg Pro',
    description: 'Convert PDF pages to high-resolution JPG or PNG online for free. Choose resolution, extract every page and download as a ZIP. Runs privately in your browser.',
    keywords: 'pdf to jpg, pdf to png, pdf to image, convert pdf pages to images, extract images from pdf',
    h1: 'Convert PDF Pages to Images',
    intro: 'Extract every page of a PDF as a sharp JPG or PNG. Pick the resolution scale and download all pages in one ZIP.',
    steps: ['Add your PDF.', 'Choose the output scale.', 'Download each page as an image.'],
    faqs: [
      { q: 'How do I convert PDF pages to JPG?', a: 'Upload the PDF, select PDF to Images, adjust the resolution scale and click Execute.' },
      { q: 'Is my PDF uploaded to a server?', a: 'No. Pages are rendered locally in your browser.' },
    ],
  },
  {
    id: 'bgremove',
    slug: 'background-remover',
    name: 'Background Remover',
    title: 'Free AI Background Remover – Remove Image Background Online | ZappImg Pro',
    description: 'Remove image backgrounds automatically with AI. Free, private and fast: one photo in seconds, whole batches in one click. Download transparent PNG. No signup, no upload.',
    keywords: 'background remover, remove background from image, remove bg, transparent background maker, ai background remover, remove background online free',
    h1: 'Free AI Background Remover',
    intro: 'Click once and the AI cuts the subject out cleanly, including hair and edges. Process a single photo in seconds or an entire batch together, then download transparent PNGs or add a white, black or custom colour background. Everything runs on your device, so your photos are never uploaded.',
    steps: ['Add one photo or many.', 'Select Auto (AI) and click Remove Background.', 'Choose single image or all images, then download.'],
    faqs: [
      { q: 'How do I remove a background from a photo?', a: 'Select Background Remover, keep Auto (AI) selected and click Remove Background. Download the transparent PNG when it finishes.' },
      { q: 'Does background removal upload my photo?', a: 'No. The AI model runs inside your browser. It downloads once and is then cached.' },
    ],
  },
  {
    id: 'crop',
    slug: 'crop-rotate-image',
    name: 'Crop & Rotate',
    title: 'Crop & Rotate Image Online – Square, 4:5, 16:9 Free | ZappImg Pro',
    description: 'Crop images to 1:1, 4:5 or 16:9 and rotate or straighten photos online for free. Batch crop up to 100 photos privately in your browser.',
    keywords: 'crop image online, rotate image, crop photo to square, straighten photo, image cropper, crop image 16:9',
    h1: 'Crop, Rotate & Straighten Photos',
    intro: 'Crop photos to popular aspect ratios, rotate them and fine-tune the horizon in bulk.',
    steps: ['Add photos.', 'Pick an aspect ratio and rotation.', 'Execute and download.'],
    faqs: [
      { q: 'Can I crop many photos to the same ratio?', a: 'Yes, every photo in the tray is cropped to the ratio you choose.' },
      { q: 'Does cropping reduce quality?', a: 'No. Pixels are copied exactly; only the frame changes.' },
    ],
  },
  {
    id: 'favicon',
    slug: 'favicon-generator',
    name: 'Favicon & App Icons',
    title: 'Favicon Generator – Create favicon.ico & App Icons Online | ZappImg Pro',
    description: 'Generate favicon.ico, Apple Touch Icon and PWA icons from any image. Multi-size ICO (16, 32, 48) and ready-to-paste HTML tags. Free and private.',
    keywords: 'favicon generator, favicon.ico maker, app icon generator, apple touch icon, pwa icons, png to ico',
    h1: 'Favicon & App Icon Generator',
    intro: 'Upload one logo and get a multi-size favicon.ico plus Apple Touch and PWA icons with the HTML snippet to paste into your site.',
    steps: ['Add your logo.', 'Select Favicon & App Icons.', 'Download the icon pack.'],
    faqs: [
      { q: 'What favicon sizes do I need?', a: 'A favicon.ico containing 16, 32 and 48 px plus 180 px Apple Touch and 192/512 px PWA icons covers all modern browsers.' },
      { q: 'Which image should I upload?', a: 'A square PNG or SVG of at least 512×512 px gives the sharpest results.' },
    ],
  },
  {
    id: 'passport',
    slug: 'passport-photo-maker',
    name: 'Passport & ID Maker',
    title: 'Passport Photo Maker – US 2x2 & UK 35x45 mm Online Free | ZappImg Pro',
    description: 'Make passport and visa photos online: US 2×2 inch and UK/EU 35×45 mm with head-position guides. Free, private, no upload.',
    keywords: 'passport photo maker, passport photo online, 2x2 photo, 35x45mm photo, visa photo, id photo maker',
    h1: 'Passport & ID Photo Maker',
    intro: 'Crop to exact US 2×2 inch or UK/EU 35×45 mm sizes with head-alignment guides. Always verify the official rules of the issuing country.',
    steps: ['Add a front-facing photo.', 'Choose US or UK/EU size.', 'Download and print.'],
    faqs: [
      { q: 'What are the passport photo sizes for the US and UK?', a: 'US passports use 2×2 inch (600×600 px at 300 DPI). UK passports use 35×45 mm.' },
      { q: 'Is my photo uploaded?', a: 'No, everything happens locally on your device.' },
    ],
  },
  {
    id: 'metadata',
    slug: 'exif-metadata-remover',
    name: 'Metadata Cleaner',
    title: 'EXIF Remover – Delete Photo Metadata & GPS Location Online | ZappImg Pro',
    description: 'Inspect and remove EXIF metadata and GPS location from photos online for free. Protect your privacy before sharing images. Runs locally in your browser.',
    keywords: 'exif remover, remove metadata from photo, remove gps from image, exif viewer, strip image metadata, photo privacy',
    h1: 'Remove EXIF & GPS Data from Photos',
    intro: 'See exactly what your photo reveals – camera model, date and GPS coordinates – and strip it before posting online.',
    steps: ['Add your photos.', 'Review the metadata found.', 'Clean and download.'],
    faqs: [
      { q: 'Is my photo location removed?', a: 'Yes. Exported images are re-encoded without EXIF, GPS or camera serial data.' },
      { q: 'Can I see the metadata first?', a: 'Yes, the tool shows camera, date and GPS information before cleaning.' },
    ],
  },
  {
    id: 'base64',
    slug: 'image-to-base64',
    name: 'Image to Base64',
    title: 'Image to Base64 Converter – Data URI & HTML img Tag Online | ZappImg Pro',
    description: 'Convert any image to a Base64 string, data URI or HTML img tag online. Copy with one click. Free and private.',
    keywords: 'image to base64, base64 encoder image, data uri generator, png to base64, convert image to base64',
    h1: 'Image to Base64 Converter',
    intro: 'Encode an image as Base64, a CSS/HTML data URI or a ready-made img tag and copy it instantly.',
    steps: ['Add an image.', 'Select Image to Base64.', 'Copy the result.'],
    faqs: [
      { q: 'What is a Base64 data URI?', a: 'It embeds the image directly in HTML or CSS as text, saving one network request.' },
      { q: 'Is there a size limit?', a: 'Keep images small (under ~100 KB) – Base64 adds roughly 33% to the size.' },
    ],
  },
];

export const toolPath = (id: ToolSlugId): string => '/' + (TOOL_SEO.find((t) => t.id === id)?.slug || '') + '/';

export function toolFromPath(pathname: string): ToolSeo | undefined {
  const slug = pathname.replace(/^\/+|\/+$/g, '');
  return TOOL_SEO.find((t) => t.slug === slug);
}

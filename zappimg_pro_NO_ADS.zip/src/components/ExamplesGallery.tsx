import React, { useState } from 'react';
import { PresetItem } from '../App';

interface ExamplesGalleryProps {
  onSelectPreset: (presetId: string) => void;
  presets: PresetItem[];
}

export const ExamplesGallery: React.FC<ExamplesGalleryProps> = ({ onSelectPreset, presets }) => {
  const [activeTab, setActiveTab] = useState<number>(0);
  const [sliderVal, setSliderVal] = useState<number>(50);

  const examples = [
    {
      id: 'ecommerce',
      presetId: 'amazon-main',
      title: 'E-Commerce Product Showcase',
      description: 'Transparent footwear photograph converted to WebP with white-isolated clean background.',
      presetName: 'Amazon Main (2000×2000)',
      beforeSize: '4.8 MB',
      beforeFormat: 'Uncompressed PNG',
      afterSize: '112 KB',
      afterFormat: 'WebP (Lossless Alpha)',
      savedPercent: '97.6%',
      beforeGradient: 'from-amber-100 to-orange-200',
      afterGradient: 'from-teal-50 to-emerald-100',
    },
    {
      id: 'portrait',
      presetId: 'ig-post',
      title: 'Studio Portrait & Social Media',
      description: 'High-ISO DSLR portrait resized to Instagram 1080×1080 with Lanczos-3 sharpening.',
      presetName: 'Instagram Square (1080×1080)',
      beforeSize: '6.4 MB',
      beforeFormat: 'Sony RAW / JPEG',
      afterSize: '184 KB',
      afterFormat: 'WebP (Quality 92)',
      savedPercent: '97.1%',
      beforeGradient: 'from-purple-100 to-indigo-200',
      afterGradient: 'from-sky-50 to-blue-100',
    },
    {
      id: 'landscape',
      presetId: 'screen-4k',
      title: 'Cinematic 4K Wallpapers',
      description: 'Mountain vista compressed for 4K desktop display without macroblocking or banding.',
      presetName: '4K Ultra HD (3840×2160)',
      beforeSize: '12.8 MB',
      beforeFormat: 'High-Res TIFF',
      afterSize: '420 KB',
      afterFormat: 'AVIF (10-bit color)',
      savedPercent: '96.7%',
      beforeGradient: 'from-rose-100 to-pink-200',
      afterGradient: 'from-emerald-50 to-teal-100',
    },
    {
      id: 'passport',
      presetId: 'us-passport-2x2',
      title: 'Official Biometric ID & Passport',
      description: 'Standard 2×2 in photo framed to exact State Dept 600×600 px geometry at 300 DPI.',
      presetName: 'US Passport (600×600 px)',
      beforeSize: '3.2 MB',
      beforeFormat: 'Phone Camera Capture',
      afterSize: '54 KB',
      afterFormat: 'JPEG (Biometric White BG)',
      savedPercent: '98.3%',
      beforeGradient: 'from-slate-200 to-gray-300',
      afterGradient: 'from-blue-50 to-indigo-100',
    },
  ];

  const current = examples[activeTab];

  return (
    <section className="py-16 max-w-[1280px] mx-auto px-4 sm:px-6 border-t border-[#E7E2D8]">
      <div className="text-center max-w-2xl mx-auto mb-10">
        <span className="text-xs uppercase font-extrabold tracking-wider text-[#0F766E]">Real-World Quality</span>
        <h2 className="text-2xl sm:text-3xl font-extrabold text-[#14171F] mt-1">
          Interactive Examples &amp; Compression Proof
        </h2>
        <p className="mt-2 text-sm text-[#4B5160]">
          Compare original master files versus ZappImg Pro client-side output across real production use cases.
        </p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-8">
        {examples.map((ex, idx) => (
          <button
            key={ex.id}
            type="button"
            data-action={`example-tab-${ex.id}`}
            onClick={() => setActiveTab(idx)}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-all ${
              activeTab === idx
                ? 'bg-[#14171F] text-white shadow-xs'
                : 'bg-white border border-[#E7E2D8] text-[#4B5160] hover:text-[#14171F] hover:bg-gray-50'
            }`}
          >
            {ex.title}
          </button>
        ))}
      </div>

      {/* Interactive Showcase Box */}
      <div className="bg-white rounded-3xl border border-[#E7E2D8] p-6 sm:p-8 shadow-[0_2px_4px_rgba(20,23,31,0.04),0_16px_36px_-10px_rgba(20,23,31,0.08)] grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
        {/* Interactive Split Viewport */}
        <div className="lg:col-span-7">
          <div className="relative w-full h-[320px] sm:h-[380px] rounded-2xl border border-[#E7E2D8] overflow-hidden select-none shadow-inner bg-checkerboard">
            {/* After layer */}
            <div
              className={`absolute inset-0 bg-gradient-to-br ${current.afterGradient} flex flex-col items-center justify-center text-center p-6`}
            >
              <div className="w-20 h-20 rounded-2xl bg-white/80 shadow-md flex items-center justify-center text-3xl mb-3">
                ✨
              </div>
              <h4 className="text-lg font-extrabold text-[#14171F]">Optimized {current.afterFormat}</h4>
              <p className="text-xs text-[#065F46] font-bold mt-1 max-w-sm">
                Output File Size: {current.afterSize} · {current.savedPercent} smaller than original
              </p>
            </div>

            {/* Before layer with clip-path */}
            <div
              className={`absolute inset-0 bg-gradient-to-br ${current.beforeGradient} flex flex-col items-center justify-center text-center p-6 pointer-events-none`}
              style={{
                clipPath: `polygon(0 0, ${sliderVal}% 0, ${sliderVal}% 100%, 0 100%)`,
                WebkitClipPath: `polygon(0 0, ${sliderVal}% 0, ${sliderVal}% 100%, 0 100%)`,
              }}
            >
              <div className="w-20 h-20 rounded-2xl bg-black/10 shadow-md flex items-center justify-center text-3xl mb-3">
                📦
              </div>
              <h4 className="text-lg font-extrabold text-[#14171F]">Original {current.beforeFormat}</h4>
              <p className="text-xs text-[#991B1B] font-bold mt-1 max-w-sm">
                Raw Uncompressed Size: {current.beforeSize}
              </p>
            </div>

            {/* Split Handle */}
            <div
              className="absolute top-0 bottom-0 w-0.5 bg-[#14171F] z-20 pointer-events-none"
              style={{ left: `${sliderVal}%` }}
            >
              <div className="w-6 h-6 rounded-full bg-white border-2 border-[#14171F] shadow-md -ml-3 mt-40 flex items-center justify-center text-[10px] font-bold">
                ↔
              </div>
            </div>

            <input
              type="range"
              min="0"
              max="100"
              value={sliderVal}
              onChange={(e) => setSliderVal(parseInt(e.target.value, 10))}
              aria-label="Interactive example comparison slider"
              className="absolute inset-0 opacity-0 cursor-ew-resize w-full h-full z-30"
            />

            <span className="absolute top-3 left-3 bg-white/95 text-[10px] font-extrabold px-2.5 py-1 rounded-lg border border-[#E7E2D8] text-slate-800 shadow-xs">
              Original: {current.beforeSize}
            </span>
            <span className="absolute top-3 right-3 bg-white/95 text-[10px] font-extrabold px-2.5 py-1 rounded-lg border border-[#A7F3D0] text-[#047857] shadow-xs">
              Output: {current.afterSize} (-{current.savedPercent})
            </span>
          </div>
          <div className="text-[11px] text-center text-[#6B7080] mt-2 font-medium">
            Drag the slider horizontally to compare original raw fidelity with optimized result.
          </div>
        </div>

        {/* Narrative & Metric Cards */}
        <div className="lg:col-span-5 space-y-5">
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-[#0F766E]">Preset Matched</span>
            <h3 className="text-xl font-extrabold text-[#14171F] mt-0.5">{current.title}</h3>
            <p className="text-xs text-[#4B5160] mt-2 leading-relaxed">{current.description}</p>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3.5 rounded-xl bg-[#F7F5F0] border border-[#E7E2D8]">
              <span className="text-[10px] uppercase font-bold text-[#6B7080]">Bandwidth Saved</span>
              <div className="text-lg font-extrabold text-[#065F46] mt-0.5">{current.savedPercent}</div>
              <span className="text-[10px] text-[#6B7080]">Faster page loads</span>
            </div>
            <div className="p-3.5 rounded-xl bg-[#F7F5F0] border border-[#E7E2D8]">
              <span className="text-[10px] uppercase font-bold text-[#6B7080]">Output Geometry</span>
              <div className="text-lg font-extrabold text-[#14171F] mt-0.5">Pixel Perfect</div>
              <span className="text-[10px] text-[#6B7080]">{current.presetName}</span>
            </div>
          </div>

          <div className="pt-2">
            <button
              type="button"
              data-action={`apply-example-${current.id}`}
              onClick={() => {
                onSelectPreset(current.presetId);
                document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth' });
              }}
              className="w-full py-3 bg-[#0F766E] hover:bg-[#115E59] text-white font-extrabold text-xs rounded-xl transition-all shadow-xs flex items-center justify-center gap-2 hover:-translate-y-0.5 active:translate-y-0"
            >
              <span>Use this preset in workspace ({current.presetName})</span>
              <span>→</span>
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

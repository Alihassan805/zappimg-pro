import React, { useState, useRef } from 'react';

interface Hero3DSceneProps {
  onChooseImages: () => void;
  onAdd3Test: () => void;
  sessionSavingsBytes?: number;
}

export const Hero3DScene: React.FC<Hero3DSceneProps> = ({
  onChooseImages,
  onAdd3Test,
  sessionSavingsBytes = 0,
}) => {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState<{ rx: number; ry: number; active: boolean }>({
    rx: 4,
    ry: -6,
    active: false,
  });

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;
    const rect = cardRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const centerX = rect.width / 2;
    const centerY = rect.height / 2;
    // Calculate subtle tilt angles (-10 to +10 degrees)
    const rx = ((centerY - y) / centerY) * 10;
    const ry = ((x - centerX) / centerX) * 10;
    setTilt({ rx, ry, active: true });
  };

  const handleMouseLeave = () => {
    setTilt({ rx: 4, ry: -6, active: false });
  };

  const formatMB = (bytes: number) => {
    if (bytes <= 0) return '0.0 MB';
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <div className="relative my-8 select-none">
      {/* 3D Perspective Container */}
      <div
        ref={cardRef}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className="perspective-1000 max-w-[820px] mx-auto cursor-pointer"
        onClick={onChooseImages}
      >
        <div
          className="preserve-3d transition-transform duration-200 ease-out rounded-3xl border border-[#E7E2D8] bg-white p-5 sm:p-7 shadow-[0_2px_4px_rgba(20,23,31,0.04),0_20px_48px_-12px_rgba(20,23,31,0.12)] hover:shadow-[0_2px_4px_rgba(20,23,31,0.04),0_28px_64px_-12px_rgba(20,23,31,0.16)]"
          style={{
            transform: `perspective(1000px) rotateX(${tilt.rx}deg) rotateY(${tilt.ry}deg) translateZ(0)`,
            willChange: 'transform',
          }}
        >
          {/* Top Stage Bar */}
          <div className="flex items-center justify-between pb-4 border-b border-[#F0EDE6] text-xs">
            <div className="flex items-center gap-2 font-bold text-[#14171F]">
              <span className="w-2.5 h-2.5 rounded-full bg-[#10B981] animate-pulse" />
              <span>GPU Accelerated Image Engine</span>
              <span className="text-[10px] text-[#6B7080] font-mono px-2 py-0.5 rounded bg-[#F7F5F0] border border-[#E7E2D8]">
                Lanczos-3 Sinc
              </span>
            </div>
            <div className="text-[11px] font-bold text-[#0F766E]">
              {sessionSavingsBytes > 0
                ? `✨ Session saved: ${formatMB(sessionSavingsBytes)}`
                : '100% In-Memory Processing'}
            </div>
          </div>

          {/* Interactive Stacked Visual Layers */}
          <div className="relative h-[240px] sm:h-[280px] my-5 rounded-2xl bg-gradient-to-br from-[#FAF8F5] via-[#F4F1EA] to-[#EBE6DC] border border-[#E7E2D8] overflow-hidden flex items-center justify-center p-4">
            {/* Background Layer: 4K Raw Capture */}
            <div
              className="absolute w-[80%] h-[72%] rounded-xl border border-white/60 bg-gradient-to-tr from-slate-800 to-slate-900 shadow-lg flex flex-col justify-between p-3.5 text-white/90"
              style={{
                transform: 'translateZ(-40px) translateY(-14px) scale(0.92)',
                willChange: 'transform',
              }}
            >
              <div className="flex justify-between text-[10px] font-mono opacity-80">
                <span>INPUT: RAW DSLR SENSOR</span>
                <span className="bg-red-500/80 px-1.5 py-0.5 rounded text-white font-bold">5.84 MB</span>
              </div>
              <div className="space-y-1">
                <div className="text-xs font-bold tracking-tight">4000 × 3000 px · 300 DPI · Full EXIF/GPS</div>
                <div className="w-full h-1 bg-white/20 rounded-full overflow-hidden">
                  <div className="w-full h-full bg-red-400" />
                </div>
              </div>
            </div>

            {/* Intermediate Layer: Filter & Strip */}
            <div
              className="absolute w-[85%] h-[76%] rounded-xl border border-[#0F766E]/30 bg-emerald-950/40 backdrop-blur-xs shadow-md flex items-center justify-center text-emerald-200"
              style={{
                transform: 'translateZ(-15px) translateY(-4px) scale(0.96)',
                willChange: 'transform',
              }}
            >
              <div className="text-center font-mono text-[11px] space-y-1">
                <span className="px-2 py-0.5 rounded bg-emerald-900/80 text-emerald-300 font-bold">
                  ⚡ Anti-Aliased Resampling &amp; Metadata Purge
                </span>
                <div className="text-[10px] opacity-75">Iterative Quality Binary Optimization</div>
              </div>
            </div>

            {/* Foreground Layer: Micro WebP / AVIF */}
            <div
              className="relative w-[90%] h-[82%] rounded-xl border border-white/90 bg-white/95 backdrop-blur-md shadow-2xl p-4 flex flex-col justify-between"
              style={{
                transform: 'translateZ(25px) translateY(8px)',
                willChange: 'transform',
              }}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-extrabold text-[#14171F]">OUTPUT: WEBP / AVIF</span>
                  <span className="text-[10px] font-extrabold bg-[#ECFDF5] text-[#047857] px-2 py-0.5 rounded-full border border-[#A7F3D0]">
                    96% REDUCTION
                  </span>
                </div>
                <span className="text-xs font-mono font-extrabold text-[#0F766E]">238 KB (0 Artifacts)</span>
              </div>

              {/* Visual Split preview */}
              <div className="grid grid-cols-2 gap-3 my-2 text-center text-[11px]">
                <div className="p-2.5 rounded-lg bg-[#F7F5F0] border border-[#E7E2D8]">
                  <div className="text-[#6B7080] text-[10px] uppercase font-bold">Before</div>
                  <div className="font-extrabold text-[#14171F] mt-0.5">5.84 MB</div>
                  <div className="text-[9px] text-[#6B7080] font-mono">Unoptimized JPG</div>
                </div>
                <div className="p-2.5 rounded-lg bg-[#ECFDF5] border border-[#A7F3D0]">
                  <div className="text-[#047857] text-[10px] uppercase font-bold">ZappImg Result</div>
                  <div className="font-extrabold text-[#065F46] mt-0.5">238 KB</div>
                  <div className="text-[9px] text-[#047857] font-mono">1080×1080 px</div>
                </div>
              </div>

              <div className="flex items-center justify-between text-[11px] text-[#6B7080]">
                <span>✓ Zero cloud latency</span>
                <span>✓ EXIF sanitized</span>
                <span>✓ Ready for web delivery</span>
              </div>
            </div>
          </div>

          {/* Bottom Quick Triggers */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-[#F0EDE6] text-xs">
            <span className="text-[#6B7080]">
              Hover and tilt to explore layers. Drag or paste anywhere to begin.
            </span>
            <div className="flex items-center gap-2" onClick={(e) => e.stopPropagation()}>
              <button
                type="button"
                data-action="hero-3d-try-sample"
                onClick={onAdd3Test}
                className="px-3 py-1.5 bg-[#F7F5F0] hover:bg-[#EAE6DD] text-[#14171F] font-bold rounded-lg border border-[#E7E2D8] transition-colors"
              >
                + Try with 3 sample scenes
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

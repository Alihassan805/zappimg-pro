import React, { useEffect, useRef, useState } from 'react';

const prefersReduced = () => typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ------------------------------------------------------------ Reveal on scroll */
export const Reveal: React.FC<{ children: React.ReactNode; delay?: number; className?: string }> = ({ children, delay = 0, className = '' }) => {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReduced() || typeof IntersectionObserver === 'undefined') {
      setShown(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setShown(true);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: '0px 0px -6% 0px' }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div ref={ref} className={`rv ${shown ? 'rv-in' : ''} ${className}`} style={{ transitionDelay: `${delay}ms` }}>
      {children}
    </div>
  );
};

/* ------------------------------------------------------------ Scroll progress bar */
export const ScrollProgress: React.FC = () => {
  const barRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    let raf = 0;
    const update = () => {
      raf = 0;
      const h = document.documentElement.scrollHeight - window.innerHeight;
      const p = h > 0 ? Math.min(1, Math.max(0, window.scrollY / h)) : 0;
      if (barRef.current) barRef.current.style.transform = `scaleX(${p})`;
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);
  return (
    <div className="fixed top-0 left-0 right-0 h-[3px] z-[80] pointer-events-none" aria-hidden="true">
      <div ref={barRef} className="h-full origin-left bg-gradient-to-r from-[#FF7A1A] via-[#C2410C] to-[#0F766E]" style={{ transform: 'scaleX(0)' }} />
    </div>
  );
};

/* ------------------------------------------------------------ Count up */
export const CountUp: React.FC<{ to: number; suffix?: string; duration?: number }> = ({ to, suffix = '', duration = 1400 }) => {
  const ref = useRef<HTMLSpanElement>(null);
  const [val, setVal] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (prefersReduced() || typeof IntersectionObserver === 'undefined') {
      setVal(to);
      return;
    }
    let raf = 0;
    const io = new IntersectionObserver((entries) => {
      if (!entries.some((e) => e.isIntersecting)) return;
      io.disconnect();
      const t0 = performance.now();
      const tick = (t: number) => {
        const k = Math.min(1, (t - t0) / duration);
        const eased = 1 - Math.pow(1 - k, 3);
        setVal(Math.round(to * eased));
        if (k < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    }, { threshold: 0.4 });
    io.observe(el);
    return () => {
      io.disconnect();
      if (raf) cancelAnimationFrame(raf);
    };
  }, [to, duration]);
  return (
    <span ref={ref} className="tabular-nums">
      {val}
      {suffix}
    </span>
  );
};

/* ------------------------------------------------------------ Apple-style scroll-lit statement */
const STATEMENT =
  'Your photos never leave your device. Cut out backgrounds with AI, resize a hundred images, convert any format — instantly, privately, for free.';

export const StatementSection: React.FC = () => {
  const pRef = useRef<HTMLParagraphElement>(null);
  const [p, setP] = useState(prefersReduced() ? 1 : 0);
  const words = STATEMENT.split(' ');

  useEffect(() => {
    if (prefersReduced()) return;
    let raf = 0;
    const update = () => {
      raf = 0;
      const el = pRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const vh = window.innerHeight;
      // words light up while the text scrolls through the screen (no tall empty scroll area)
      const prog = (vh * 0.88 - r.top) / (vh * 0.38 + r.height);
      setP(Math.min(1, Math.max(0, prog)));
    };
    const onScroll = () => {
      if (!raf) raf = requestAnimationFrame(update);
    };
    update();
    window.addEventListener('scroll', onScroll, { passive: true });
    window.addEventListener('resize', onScroll, { passive: true });
    return () => {
      window.removeEventListener('scroll', onScroll);
      window.removeEventListener('resize', onScroll);
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <section aria-label="What ZappImg Pro is" className="relative bg-[#0C0E13] overflow-hidden px-5 sm:px-10 py-20 sm:py-32">
      <div className="absolute inset-0 opacity-60 pointer-events-none" aria-hidden="true" style={{ background: 'radial-gradient(60% 60% at 50% 50%, rgba(255,122,26,.16), transparent 70%)' }} />
      <p ref={pRef} className="relative max-w-5xl mx-auto text-[27px] leading-[1.18] sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-center" style={{ fontFamily: "'Plus Jakarta Sans', system-ui, sans-serif" }}>
        {words.map((w, i) => {
          const start = (i / words.length) * 0.82;
          const k = Math.min(1, Math.max(0, (p - start) / 0.16));
          return (
            <span key={i} style={{ color: `rgba(255,255,255,${0.2 + 0.8 * k})` }}>
              {w}{' '}
            </span>
          );
        })}
      </p>
    </section>
  );
};

/* ------------------------------------------------------------ Bento grid */
export const BentoGrid: React.FC<{ onOpenTool: (id: string) => void }> = ({ onOpenTool }) => (
  <section aria-labelledby="bento-title" className="bg-[#F7F5F0] py-12 sm:py-24">
    <div className="max-w-[1180px] mx-auto px-4 sm:px-6">
      <Reveal>
        <h2 id="bento-title" className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#14171F] text-center">
          Powerful. <span className="text-[#C2410C]">Private.</span> Instant.
        </h2>
        <p className="mt-3 text-center text-[#4B5160] max-w-xl mx-auto text-sm sm:text-base">Everything you need for images, designed to get out of your way.</p>
      </Reveal>

      <div className="mt-10 grid grid-cols-1 md:grid-cols-6 gap-4 md:auto-rows-[minmax(220px,auto)]">
        {/* AI cutout */}
        <Reveal className="md:col-span-4 md:row-span-1">
          <div className="zb-tile h-full bg-[#14171F] text-white relative overflow-hidden">
            <div className="relative z-10 max-w-sm">
              <div className="text-[11px] font-extrabold uppercase tracking-widest text-[#FFB066]">AI Background Remover</div>
              <h3 className="mt-2 text-2xl sm:text-4xl font-extrabold tracking-tight leading-tight">Cut out. In one click.</h3>
              <p className="mt-2 text-sm text-white/65">Hair, edges, everything. One photo or a hundred.</p>
              <button type="button" onClick={() => onOpenTool('bgremove')} className="mt-5 px-4 py-2 rounded-full bg-white text-[#14171F] text-xs font-extrabold hover:bg-[#F7F5F0]">
                Try it free →
              </button>
            </div>
            <div className="zb-scan" aria-hidden="true">
              <svg viewBox="0 0 200 200" className="w-full h-full">
                <defs>
                  <pattern id="zbchk" width="16" height="16" patternUnits="userSpaceOnUse">
                    <rect width="16" height="16" fill="#2A2F3C" />
                    <rect width="8" height="8" fill="#343A49" />
                    <rect x="8" y="8" width="8" height="8" fill="#343A49" />
                  </pattern>
                </defs>
                <rect width="200" height="200" fill="url(#zbchk)" />
                <circle cx="100" cy="72" r="30" fill="#FFB066" />
                <path d="M36 200c0-44 28-72 64-72s64 28 64 72z" fill="#FF7A1A" />
                <rect className="zb-scanline" x="0" y="0" width="200" height="4" fill="#fff" opacity=".85" />
              </svg>
            </div>
          </div>
        </Reveal>

        {/* Privacy */}
        <Reveal delay={80} className="md:col-span-2">
          <div className="zb-tile h-full bg-white border border-[#E7E2D8]">
            <div className="text-4xl zb-float" aria-hidden="true">🔒</div>
            <h3 className="mt-3 text-xl sm:text-2xl font-extrabold tracking-tight text-[#14171F]">Zero uploads.</h3>
            <p className="mt-1 text-sm text-[#4B5160]">Everything happens on your device.</p>
            <div className="mt-4 text-4xl font-extrabold text-[#0F766E]"><CountUp to={0} suffix=" bytes" /></div>
            <div className="text-xs font-bold text-[#6B7080]">sent to any server</div>
          </div>
        </Reveal>

        {/* Batch */}
        <Reveal delay={0} className="md:col-span-2">
          <div className="zb-tile h-full bg-white border border-[#E7E2D8] overflow-hidden relative">
            <div className="text-5xl sm:text-6xl font-extrabold tracking-tight text-[#14171F]"><CountUp to={100} /></div>
            <h3 className="text-xl font-extrabold text-[#14171F]">photos at once.</h3>
            <p className="mt-1 text-sm text-[#4B5160]">Drop a folder, get one ZIP.</p>
            <div className="zb-stack" aria-hidden="true">
              <span /><span /><span />
            </div>
          </div>
        </Reveal>

        {/* Sizes */}
        <Reveal delay={80} className="md:col-span-2">
          <div className="zb-tile h-full bg-gradient-to-br from-[#0F766E] to-[#0B4F4A] text-white">
            <div className="text-5xl sm:text-6xl font-extrabold tracking-tight"><CountUp to={110} suffix="+" /></div>
            <h3 className="text-xl font-extrabold">ready-made sizes.</h3>
            <p className="mt-1 text-sm text-white/75">Instagram, YouTube, LinkedIn, passport and more.</p>
            <a href="#size-guide" className="inline-block mt-4 text-xs font-extrabold underline underline-offset-4">See the size guide →</a>
          </div>
        </Reveal>

        {/* Speed */}
        <Reveal delay={160} className="md:col-span-2">
          <div className="zb-tile h-full bg-white border border-[#E7E2D8]">
            <div className="text-[11px] font-extrabold uppercase tracking-widest text-[#C2410C]">Speed</div>
            <h3 className="mt-2 text-xl sm:text-2xl font-extrabold tracking-tight text-[#14171F]">Starts the moment you drop a file.</h3>
            <div className="zb-bar mt-5" aria-hidden="true"><span /></div>
            <p className="mt-3 text-xs text-[#6B7080]">No upload. No queue. No waiting room.</p>
          </div>
        </Reveal>
      </div>
    </div>
  </section>
);

/* ------------------------------------------------------------ Before / After demo (real sample photos) */
const SAMPLES = [
  { id: 1, label: 'Portrait', before: '/samples/s1-before.jpg', after: '/samples/s1-after.webp' },
  { id: 2, label: 'Studio', before: '/samples/s2-before.jpg', after: '/samples/s2-after.webp' },
  { id: 3, label: 'Outdoor light', before: '/samples/s3-before.jpg', after: '/samples/s3-after.webp' },
  { id: 4, label: 'Casual', before: '/samples/s4-before.jpg', after: '/samples/s4-after.webp' },
  { id: 5, label: 'Colour pop', before: '/samples/s5-before.jpg', after: '/samples/s5-after.webp' },
];
const NEW_BGS: { label: string; css: string }[] = [
  { label: 'Transparent', css: 'transparent' },
  { label: 'White', css: '#FFFFFF' },
  { label: 'Teal', css: 'linear-gradient(160deg,#14968A,#08423E)' },
  { label: 'Orange', css: 'linear-gradient(160deg,#FFA046,#C2410C)' },
  { label: 'Indigo', css: 'linear-gradient(160deg,#5460E8,#1B225A)' },
];

export const DemoSlider: React.FC = () => {
  const box = useRef<HTMLDivElement>(null);
  const [pos, setPos] = useState(92);
  const [sel, setSel] = useState(0);
  const [bg, setBg] = useState(0);
  const dragging = useRef(false);
  const touched = useRef(false);

  // preload every sample once, so switching photos never flashes or shows half-loaded images
  useEffect(() => {
    SAMPLES.forEach((sm) => {
      const a = new Image(); a.decoding = 'async'; a.src = sm.before;
      const b = new Image(); b.decoding = 'async'; b.src = sm.after;
    });
  }, []);

  useEffect(() => {
    const el = box.current;
    if (!el || prefersReduced() || typeof IntersectionObserver === 'undefined') {
      setPos(50);
      return;
    }
    let raf = 0;
    const io = new IntersectionObserver((entries) => {
      if (!entries.some((e) => e.isIntersecting)) return;
      io.disconnect();
      const t0 = performance.now();
      const tick = (t: number) => {
        if (touched.current) return;
        const k = Math.min(1, (t - t0) / 1600);
        setPos(92 - 42 * (1 - Math.pow(1 - k, 3)));
        if (k < 1) raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    }, { threshold: 0.45 });
    io.observe(el);
    return () => {
      io.disconnect();
      if (raf) cancelAnimationFrame(raf);
    };
  }, []);

  const move = (clientX: number) => {
    const el = box.current;
    if (!el) return;
    const r = el.getBoundingClientRect();
    setPos(Math.min(100, Math.max(0, ((clientX - r.left) / r.width) * 100)));
  };
  const cur = SAMPLES[sel];
  const bgCss = NEW_BGS[bg].css;

  return (
    <section aria-labelledby="demo-title" className="bg-white py-12 sm:py-24 border-t border-[#E7E2D8]">
      <div className="max-w-[980px] mx-auto px-4 sm:px-6">
        <Reveal>
          <h2 id="demo-title" className="text-3xl sm:text-5xl font-extrabold tracking-tight text-[#14171F] text-center">See the difference.</h2>
          <p className="mt-3 text-center text-[#4B5160] text-sm sm:text-base">Drag to compare. Pick a sample photo and a new background.</p>
        </Reveal>

        <Reveal delay={100}>
          <div className="mt-8 grid md:grid-cols-[1fr_auto] gap-6 items-start justify-center">
            <div
              ref={box}
              className="relative mx-auto w-full max-w-[460px] aspect-[3/4] rounded-3xl overflow-hidden border border-[#E7E2D8] shadow-[0_30px_60px_-30px_rgba(20,23,31,.45)] select-none cursor-ew-resize bg-checkerboard"
              style={{ touchAction: 'pan-y', isolation: 'isolate', transform: 'translateZ(0)' }}
              onPointerDown={(e) => {
                dragging.current = true;
                touched.current = true;
                try { (e.currentTarget as HTMLElement).setPointerCapture(e.pointerId); } catch (err) {}
                move(e.clientX);
              }}
              onPointerMove={(e) => { if (dragging.current) move(e.clientX); }}
              onPointerUp={(e) => {
                dragging.current = false;
                try { (e.currentTarget as HTMLElement).releasePointerCapture(e.pointerId); } catch (err) {}
              }}
              onPointerCancel={() => { dragging.current = false; }}
              onLostPointerCapture={() => { dragging.current = false; }}
              onDragStart={(e) => e.preventDefault()}
            >
              <div className="absolute inset-0" style={{ background: bgCss === 'transparent' ? undefined : bgCss }} />
              <img key={`a${cur.id}`} src={cur.after} alt={`${cur.label} sample with background removed`} className="absolute inset-0 w-full h-full object-cover zv-fade pointer-events-none" draggable={false} decoding="async" />
              <div className="absolute inset-0 pointer-events-none" style={{ clipPath: `inset(0 ${100 - pos}% 0 0)`, WebkitClipPath: `inset(0 ${100 - pos}% 0 0)`, willChange: 'clip-path' }}>
                <img key={`b${cur.id}`} src={cur.before} alt={`${cur.label} sample, original`} className="absolute inset-0 w-full h-full object-cover zv-fade pointer-events-none" draggable={false} decoding="async" />
              </div>
              <span className="absolute top-3 left-3 text-[11px] font-extrabold px-2.5 py-1 rounded-full bg-black/55 text-white backdrop-blur">Original</span>
              <span className="absolute top-3 right-3 text-[11px] font-extrabold px-2.5 py-1 rounded-full bg-white/85 text-[#14171F] backdrop-blur">Background removed</span>
              <div className="absolute top-0 bottom-0 w-0.5 bg-white shadow-[0_0_12px_rgba(0,0,0,.4)]" style={{ left: `${pos}%`, willChange: 'left' }}>
                <button
                  type="button"
                  role="slider"
                  aria-label="Before and after comparison"
                  aria-valuemin={0}
                  aria-valuemax={100}
                  aria-valuenow={Math.round(pos)}
                  onKeyDown={(e) => {
                    touched.current = true;
                    if (e.key === 'ArrowLeft') setPos((v) => Math.max(0, v - 4));
                    if (e.key === 'ArrowRight') setPos((v) => Math.min(100, v + 4));
                  }}
                  className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-11 h-11 rounded-full bg-white shadow-xl flex items-center justify-center text-[#14171F] font-extrabold text-sm"
                >
                  ⇆
                </button>
              </div>
            </div>

            <div className="flex md:flex-col gap-5 md:gap-6 justify-center md:w-56">
              <div>
                <div className="text-[11px] font-extrabold uppercase tracking-wider text-[#6B7080] mb-2">Sample photo</div>
                <div className="flex md:grid md:grid-cols-3 gap-2 flex-wrap">
                  {SAMPLES.map((sm, i) => (
                    <button
                      key={sm.id}
                      type="button"
                      aria-label={`Use ${sm.label} sample`}
                      onClick={() => { setSel(i); touched.current = true; }}
                      className={`w-12 h-12 rounded-xl overflow-hidden border-2 ${sel === i ? 'border-[#C2410C]' : 'border-[#E7E2D8]'}`}
                    >
                      <img src={sm.before} alt="" className="w-full h-full object-cover" loading="lazy" />
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <div className="text-[11px] font-extrabold uppercase tracking-wider text-[#6B7080] mb-2">New background</div>
                <div className="flex gap-2 flex-wrap">
                  {NEW_BGS.map((n, i) => (
                    <button
                      key={n.label}
                      type="button"
                      aria-label={`${n.label} background`}
                      title={n.label}
                      onClick={() => setBg(i)}
                      className={`w-9 h-9 rounded-full border-2 ${bg === i ? 'border-[#C2410C]' : 'border-[#E7E2D8]'} ${n.css === 'transparent' ? 'bg-checkerboard' : ''}`}
                      style={n.css === 'transparent' ? undefined : { background: n.css }}
                    />
                  ))}
                </div>
              </div>
            </div>
          </div>
          <p className="mt-6 text-center text-[11px] text-[#6B7080]">
            Sample portraits are stock / AI-generated images used for illustration only – they are not our team or customers. Results shown are a preview.
          </p>
        </Reveal>
      </div>
    </section>
  );
};

/* ------------------------------------------------------------ Mobile dock (app-like bottom navigation) */
export const MobileDock: React.FC<{ onOpenTool: (id: string) => void }> = ({ onOpenTool }) => {
  const [hidden, setHidden] = useState(false);
  const lastY = useRef(0);

  useEffect(() => {
    // light haptic tick on touch devices (Android; ignored elsewhere)
    const coarse = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
    const tick = (e: Event) => {
      const t = e.target as HTMLElement | null;
      if (coarse && t && t.closest && t.closest('button, [role="button"]') && (navigator as any).vibrate) {
        try { (navigator as any).vibrate(6); } catch (err) {}
      }
    };
    document.addEventListener('pointerdown', tick, { passive: true });
    // hide the dock while scrolling down, bring it back when scrolling up
    const onScroll = () => {
      const y = window.scrollY;
      if (Math.abs(y - lastY.current) > 8) {
        setHidden(y > lastY.current && y > 400);
        lastY.current = y;
      }
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => {
      document.removeEventListener('pointerdown', tick);
      window.removeEventListener('scroll', onScroll);
    };
  }, []);

  const items: { icon: string; label: string; act: () => void }[] = [
    { icon: '🛠️', label: 'Tools', act: () => document.getElementById('workspace')?.scrollIntoView({ behavior: 'smooth' }) },
    { icon: '✨', label: 'Remove BG', act: () => onOpenTool('bgremove') },
    { icon: '📐', label: 'Sizes', act: () => document.getElementById('size-guide')?.scrollIntoView({ behavior: 'smooth' }) },
    { icon: '⬆️', label: 'Top', act: () => window.scrollTo({ top: 0, behavior: 'smooth' }) },
  ];

  return (
    <nav
      aria-label="Quick navigation"
      className={`md:hidden fixed left-1/2 -translate-x-1/2 z-[60] transition-transform duration-300 ${hidden ? 'translate-y-[140%]' : 'translate-y-0'}`}
      style={{ bottom: 'calc(12px + env(safe-area-inset-bottom, 0px))' }}
    >
      <div className="flex items-center gap-1 px-2 py-2 rounded-full bg-[#14171F]/90 backdrop-blur-xl border border-white/10 shadow-[0_18px_40px_-12px_rgba(0,0,0,.6)]">
        {items.map((it) => (
          <button
            key={it.label}
            type="button"
            onClick={it.act}
            className="flex flex-col items-center justify-center px-3.5 py-1.5 rounded-full text-white active:bg-white/15 transition-colors"
          >
            <span className="text-base leading-none">{it.icon}</span>
            <span className="text-[10px] font-bold mt-0.5 text-white/80">{it.label}</span>
          </button>
        ))}
      </div>
    </nav>
  );
};

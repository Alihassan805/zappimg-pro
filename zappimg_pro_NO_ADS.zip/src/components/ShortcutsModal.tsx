import React from 'react';

interface ShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const ShortcutsModal: React.FC<ShortcutsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    { key: 'Ctrl + V / ⌘V', desc: 'Paste image directly from system clipboard into tray' },
    { key: 'Delete / ⌫', desc: 'Remove the currently focused image from shared tray' },
    { key: 'Ctrl + ↵ / ⌘↵', desc: 'Execute current tool / Download all processed ZIP' },
    { key: 'Escape', desc: 'Close dialogs, menus, or modals' },
    { key: '?', desc: 'Toggle this keyboard shortcuts cheat sheet' },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white w-full max-w-md rounded-3xl border border-[#E7E2D8] p-6 shadow-2xl relative animate-in fade-in zoom-in-95 duration-150">
        <button
          type="button"
          onClick={onClose}
          className="absolute top-4 right-4 w-7 h-7 rounded-full bg-gray-100 hover:bg-gray-200 flex items-center justify-center text-sm font-bold text-gray-700"
          aria-label="Close shortcuts modal"
        >
          ×
        </button>

        <div className="flex items-center gap-2 mb-1">
          <span className="text-lg">⌨️</span>
          <h3 className="text-base font-extrabold text-[#14171F]">Keyboard Shortcuts</h3>
        </div>
        <p className="text-xs text-[#6B7080] mb-5">
          Work at the speed of thought without touching your mouse.
        </p>

        <div className="space-y-2.5">
          {shortcuts.map((sc, i) => (
            <div
              key={i}
              className="flex items-center justify-between p-2.5 rounded-xl bg-[#F7F5F0] border border-[#E7E2D8] text-xs"
            >
              <span className="text-[#4B5160] font-medium">{sc.desc}</span>
              <kbd className="px-2.5 py-1 rounded-md bg-white border border-[#D9D3C7] shadow-2xs font-mono font-bold text-[#14171F] text-[11px] whitespace-nowrap ml-2">
                {sc.key}
              </kbd>
            </div>
          ))}
        </div>

        <div className="mt-6 pt-4 border-t border-[#F0EDE6] flex items-center justify-between text-xs text-[#6B7080]">
          <span>Pro tip: Press <kbd className="px-1.5 py-0.5 rounded bg-gray-100 border text-[10px] font-mono">?</kbd> anytime</span>
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-1.5 bg-[#14171F] text-white font-bold rounded-lg hover:bg-black"
          >
            Got it
          </button>
        </div>
      </div>
    </div>
  );
};

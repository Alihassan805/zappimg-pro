import React, { useEffect, useMemo, useState } from 'react';
import type { PresetItem } from '../App';
import type { LifetimeStats } from '../lib/stats';

export interface ToolInfo {
  id: string;
  name: string;
  icon: string;
  desc: string;
}

const fmtBytes = (b: number) => {
  if (b <= 0) return '0 MB';
  if (b < 1024 * 1024) return `${Math.round(b / 1024)} KB`;
  if (b < 1024 * 1024 * 1024) return `${(b / (1024 * 1024)).toFixed(1)} MB`;
  return `${(b / (1024 * 1024 * 1024)).toFixed(2)} GB`;
};

const TIPS: string[] = [
  'WebP files are usually 25–35% smaller than JPG or PNG at the same visual quality – ideal for faster websites.',
  'Use JPG for photos and PNG for logos, screenshots and anything that needs a transparent background.',
  'Instagram portrait posts at 1080×1350 (4:5) take up more of the feed than square posts.',
  'Photos can carry GPS coordinates. Run them through the Metadata Cleaner before posting pictures taken at home.',
  'Many government and job portals ask for photos under 100 KB. Set the target size to 100 and let the engine find the best quality.',
  'Press Ctrl + V (⌘ + V on Mac) to paste a screenshot straight into the tray – no saving needed.',
  'Start favicons from a square image of at least 512×512 px for the sharpest result at small sizes.',
  'For product listings, remove the background and choose a white background – marketplaces love clean white shots.',
  'Quality 80–85 is usually visually identical to 100 for JPG and WebP, at a fraction of the file size.',
  'Resize images to the size they are displayed at. Serving a 4000 px photo in a 600 px slot only slows your page down.',
  'AVIF is even smaller than WebP, but check that your audience’s browsers support it.',
  'iPhone HEIC photos do not open everywhere. Convert them to JPG before sending to Windows or Android users.',
  'YouTube thumbnails work best at 1280×720 px and must stay under 2 MB.',
  'Press ? anywhere on the page to see every keyboard shortcut.',
  'Ctrl + Enter (⌘ + Enter) downloads your whole batch as a ZIP in one go.',
  'Upscaling cannot invent detail. Always start from the largest original you have.',
  'Keep your original photos. Re-saving a JPG again and again slowly lowers its quality.',
  'Descriptive file names such as red-running-shoes.webp help your images show up in Google Images.',
  'Always add alt text to website images – it helps accessibility and search engines.',
  'Keep important content in the centre of social images – platforms crop the edges differently.',
  'Merge scanned pages into one PDF with Images to PDF and email a single, tidy file.',
  'Base64 images are best for tiny icons (about 10 KB or less); larger ones make your HTML heavy.',
  'You can process up to 100 photos at once. Select all, apply one preset, download one ZIP.',
  'Solid-colour backgrounds (white studio shots) can be removed instantly in Manual mode.',
  'LinkedIn personal banners are 1584×396 px – keep your name and face away from the left edge on mobile.',
  'For printing, 300 DPI is the usual target. A 4×6 inch print needs about 1200×1800 px.',
  'Compress photos before attaching them to emails – they send faster and avoid size-limit bounces.',
  'Rotate and straighten tilted horizons in Crop & Rotate before resizing for the best framing.',
  'Check your passport photo against the official government guidelines before printing.',
  'Transparent PNG results from the Background Remover can be dropped onto any colour or design.',
];

/* ---------------------------------------------------------------- Dashboard */
export const WelcomeDashboard: React.FC<{
  stats: LifetimeStats;
  tools: ToolInfo[];
  onOpenTool: (id: string) => void;
}> = ({ stats, tools, onOpenTool }) => {
  const day = Math.floor(Date.now() / 86400000);
  const tip = TIPS[day % TIPS.length];
  const toolOfDay = tools[day % tools.length];
  const [installEvt, setInstallEvt] = useState<any>(null);
  const [hint, setHint] = useState(false);
  const isMac = typeof navigator !== 'undefined' && /Mac|iPhone|iPad/i.test(navigator.platform || navigator.userAgent);

  useEffect(() => {
    const h = (e: Event) => {
      e.preventDefault();
      setInstallEvt(e);
    };
    window.addEventListener('beforeinstallprompt', h);
    return () => window.removeEventListener('beforeinstallprompt', h);
  }, []);

  const returning = stats.visits > 1;

  return (
    <section aria-labelledby="dash-title" className="max-w-[1280px] mx-auto px-4 sm:px-6 mt-10 sm:mt-14">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Welcome + stats */}
        <div className="lg:col-span-2 bg-[#14171F] text-white rounded-2xl p-6 relative overflow-hidden">
          <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-[#FF7A1A]/15 blur-2xl" aria-hidden="true" />
          <h2 id="dash-title" className="text-xl sm:text-2xl font-extrabold tracking-tight">
            {returning ? `Welcome back! 👋 Visit #${stats.visits}` : 'Welcome to ZappImg Pro ⚡'}
          </h2>
          <p className="text-sm text-white/70 mt-1">
            {stats.images > 0
              ? 'Your personal stats – stored only on this device, never uploaded.'
              : 'Process your first photo and your personal stats will start counting here.'}
          </p>
          <div className="grid grid-cols-3 gap-3 mt-5">
            {[
              { v: stats.images.toLocaleString(), l: 'Images processed' },
              { v: fmtBytes(stats.bytesSaved), l: 'Space saved' },
              { v: String(Math.max(1, stats.visits)), l: 'Visits' },
            ].map((s) => (
              <div key={s.l} className="rounded-xl bg-white/5 border border-white/10 p-3 text-center">
                <div className="text-lg sm:text-2xl font-extrabold tabular-nums text-[#FFB066]">{s.v}</div>
                <div className="text-[10px] sm:text-xs text-white/60 font-semibold">{s.l}</div>
              </div>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-2 mt-5">
            <button
              type="button"
              data-action="bookmark"
              onClick={() => setHint(true)}
              className="px-4 py-2 rounded-xl bg-white text-[#14171F] text-xs font-extrabold hover:bg-[#F7F5F0]"
            >
              🔖 Bookmark this page
            </button>
            {installEvt && (
              <button
                type="button"
                data-action="install-app"
                onClick={async () => {
                  try {
                    installEvt.prompt();
                    await installEvt.userChoice;
                  } catch (e) {}
                  setInstallEvt(null);
                }}
                className="px-4 py-2 rounded-xl bg-[#C2410C] text-white text-xs font-extrabold hover:bg-[#9A3412]"
              >
                ⬇ Install as app
              </button>
            )}
            {hint && (
              <span className="text-xs text-white/80 zv-pop">
                Press <kbd className="px-1.5 py-0.5 rounded bg-white/15 font-mono">{isMac ? '⌘' : 'Ctrl'} + D</kbd> to bookmark – one click away next time.
              </span>
            )}
          </div>
        </div>

        {/* Tip + tool of the day */}
        <div className="space-y-4">
          <div className="bg-white rounded-2xl border border-[#E7E2D8] p-5">
            <div className="text-[11px] font-extrabold uppercase tracking-wider text-[#0F766E]">💡 Tip of the day</div>
            <p className="text-sm text-[#14171F] font-semibold leading-relaxed mt-2">{tip}</p>
          </div>
          <div className="bg-white rounded-2xl border border-[#E7E2D8] p-5">
            <div className="text-[11px] font-extrabold uppercase tracking-wider text-[#C2410C]">⭐ Tool of the day</div>
            <div className="flex items-center justify-between gap-3 mt-2">
              <div>
                <div className="text-sm font-extrabold text-[#14171F]">
                  {toolOfDay.icon} {toolOfDay.name}
                </div>
                <div className="text-xs text-[#6B7080] mt-0.5">{toolOfDay.desc}</div>
              </div>
              <button
                type="button"
                onClick={() => onOpenTool(toolOfDay.id)}
                className="px-3 py-2 rounded-lg bg-[#14171F] text-white text-xs font-bold hover:bg-black whitespace-nowrap"
              >
                Try it
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

/* ---------------------------------------------------------------- Size guide */
type Cat = 'all' | PresetItem['category'];
const CAT_LABEL: Record<Cat, string> = {
  all: 'All',
  social: 'Social',
  marketplace: 'Marketplace',
  devices: 'Devices',
  print: 'Print',
  documents: 'Documents',
  web: 'Web',
};

export const SizeGuide: React.FC<{ presets: PresetItem[]; onUse: (p: PresetItem) => void }> = ({ presets, onUse }) => {
  const [cat, setCat] = useState<Cat>('all');
  const [q, setQ] = useState('');
  const [all, setAll] = useState(false);

  const list = useMemo(() => {
    const t = q.trim().toLowerCase();
    return presets.filter((p) => (cat === 'all' || p.category === cat) && (!t || p.name.toLowerCase().includes(t) || (p.desc || '').toLowerCase().includes(t)));
  }, [presets, cat, q]);
  const shown = all || q || cat !== 'all' ? list : list.slice(0, 12);

  return (
    <section id="size-guide" aria-labelledby="size-title" className="py-12 sm:py-16 bg-white border-t border-[#E7E2D8]">
      <div className="max-w-[1280px] mx-auto px-4 sm:px-6">
        <div className="text-center max-w-2xl mx-auto mb-8">
          <h2 id="size-title" className="text-2xl sm:text-3xl font-extrabold text-[#14171F]">Image size cheat sheet</h2>
          <p className="mt-2 text-sm text-[#4B5160]">
            Exact pixel sizes for {presets.length}+ platforms. Click <strong>Use size</strong> and the resizer is set up for you.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between mb-5">
          <div className="flex flex-wrap gap-1.5" role="tablist" aria-label="Size categories">
            {(Object.keys(CAT_LABEL) as Cat[]).map((c) => (
              <button
                key={c}
                type="button"
                role="tab"
                aria-selected={cat === c}
                onClick={() => setCat(c)}
                className={`px-3 py-1.5 rounded-full text-xs font-bold border ${
                  cat === c ? 'bg-[#14171F] text-white border-[#14171F]' : 'bg-white border-[#E7E2D8] text-[#14171F] hover:bg-[#F7F5F0]'
                }`}
              >
                {CAT_LABEL[c]}
              </button>
            ))}
          </div>
          <input
            type="search"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Search: Instagram, YouTube, passport…"
            aria-label="Search sizes"
            className="px-3 py-2 rounded-xl border border-[#E7E2D8] text-sm bg-[#F7F5F0] w-full sm:w-72"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {shown.map((p) => (
            <div key={p.id} className="zv-card flex items-center justify-between gap-3 p-3.5 rounded-xl border border-[#E7E2D8] bg-[#F7F5F0]/50">
              <div className="min-w-0">
                <div className="text-sm font-extrabold text-[#14171F] truncate">{p.name}</div>
                <div className="text-xs text-[#6B7080] tabular-nums">
                  {p.w} × {p.h} px · {p.ratioStr}
                  {p.desc ? ` · ${p.desc}` : ''}
                </div>
              </div>
              <button
                type="button"
                onClick={() => onUse(p)}
                className="px-3 py-1.5 rounded-lg bg-[#0F766E] hover:bg-[#0B5C56] text-white text-xs font-bold whitespace-nowrap"
              >
                Use size
              </button>
            </div>
          ))}
          {shown.length === 0 && <p className="text-sm text-[#6B7080] col-span-full text-center py-6">No sizes match your search.</p>}
        </div>

        {!all && !q && cat === 'all' && list.length > 12 && (
          <div className="text-center mt-6">
            <button type="button" onClick={() => setAll(true)} className="px-5 py-2.5 rounded-xl border border-[#14171F] text-[#14171F] text-xs font-extrabold hover:bg-[#14171F] hover:text-white transition-colors">
              Show all {list.length} sizes
            </button>
          </div>
        )}
      </div>
    </section>
  );
};

/* ---------------------------------------------------------------- Trust (honest, verifiable) */
export const TrustSection: React.FC = () => (
  <section aria-labelledby="trust-title" className="py-12 sm:py-20 bg-[#14171F] text-white border-t border-white/10">
    <div className="max-w-[1100px] mx-auto px-4 sm:px-6">
      <div className="text-center max-w-2xl mx-auto">
        <h2 id="trust-title" className="text-2xl sm:text-4xl font-extrabold tracking-tight">Don’t take our word for it.</h2>
        <p className="mt-3 text-sm sm:text-base text-white/65">Privacy claims are easy to make. Here is how you can check this one yourself in 30 seconds.</p>
      </div>
      <ol className="mt-8 grid gap-3 sm:grid-cols-3">
        {[
          { n: '1', t: 'Open developer tools', d: 'Press F12 (or ⌘⌥I on Mac) and open the Network tab.' },
          { n: '2', t: 'Process a photo', d: 'Resize, convert or remove a background as usual.' },
          { n: '3', t: 'Watch the requests', d: 'You will see no upload of your image. The only download is the AI model, once, the first time you use it.' },
        ].map((x) => (
          <li key={x.n} className="rounded-2xl bg-white/5 border border-white/10 p-5">
            <div className="w-8 h-8 rounded-full bg-[#FF7A1A] text-[#14171F] font-extrabold flex items-center justify-center text-sm">{x.n}</div>
            <div className="mt-3 font-extrabold">{x.t}</div>
            <p className="mt-1 text-xs sm:text-sm text-white/65 leading-relaxed">{x.d}</p>
          </li>
        ))}
      </ol>
      <div className="mt-6 grid gap-3 sm:grid-cols-3 text-xs sm:text-sm">
        {[
          ['Free to use', 'No watermarks, no hidden limits, and we never look at or sell your photos.'],
          ['No account needed', 'Use every tool without signing up. Signing in only adds optional extras.'],
          ['Your files, your device', 'Images are processed in your browser memory and disappear when you close the tab.'],
        ].map(([t, d]) => (
          <div key={t} className="rounded-2xl border border-white/10 p-4">
            <div className="font-extrabold text-[#FFB066]">{t}</div>
            <p className="mt-1 text-white/65 leading-relaxed">{d}</p>
          </div>
        ))}
      </div>
    </div>
  </section>
);

/* ---------------------------------------------------------------- Footer brand band */
export const FooterBrand: React.FC<{ logo: React.ReactNode }> = ({ logo }) => {
  const sparks = [6, 14, 23, 31, 40, 49, 58, 66, 75, 83, 91];
  return (
    <div className="zf-band relative overflow-hidden" aria-label="ZappImg Pro">
      <div className="zf-line" aria-hidden="true" />
      {sparks.map((left, i) => (
        <span key={left} className="zf-spark" aria-hidden="true" style={{ left: `${left}%`, animationDelay: `${(i * 0.9) % 7}s`, animationDuration: `${6 + (i % 4)}s` }} />
      ))}
      <div className="relative max-w-[1280px] mx-auto px-4 sm:px-6 pt-14 pb-10 flex flex-col items-center text-center">
        <div className="flex items-center gap-3 mb-4">
          <div className="w-12 h-12">{logo}</div>
          <span className="text-xs sm:text-sm font-bold tracking-[.25em] uppercase text-white/50">Image tools, reimagined</span>
        </div>
        <div className="zf-word" aria-hidden="true">
          <span className="zf-zapp">Zapp</span>
          <span className="zf-img">Img</span>
          <span className="zf-pro">PRO</span>
        </div>
        <p className="mt-5 text-sm text-white/60 max-w-xl">
          Resize, compress, convert and cut out backgrounds – instantly, privately, right in your browser.
        </p>
        <div className="mt-6 flex flex-wrap items-center justify-center gap-2 text-[11px] font-bold text-white/70">
          {['100% private', 'No sign-up', 'Batch up to 100', 'AI background remover'].map((t) => (
            <span key={t} className="px-3 py-1 rounded-full border border-white/15 bg-white/5">{t}</span>
          ))}
        </div>
        <p className="mt-8 text-[11px] text-white/35">© {new Date().getFullYear()} ZappImg Pro · Made with ⚡ for creators everywhere</p>
      </div>
    </div>
  );
};

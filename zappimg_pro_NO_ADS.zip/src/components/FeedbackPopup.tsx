import React, { useEffect, useRef, useState } from 'react';

const KEY = 'zapp_feedback_v1';
const REASONS = ['Too slow', 'Hard to use', 'Results not good', 'Too many ads', 'Missing a feature'];

/**
 * "Are you liking this website?" – appears once, 10–15 s after arrival (random), never while the visitor is busy.
 * Answers are posted to Netlify Forms (form name: "feedback"), so they show up in your Netlify dashboard → Forms.
 */
export const FeedbackPopup: React.FC<{ busy: boolean }> = ({ busy }) => {
  const [open, setOpen] = useState(false);
  const [step, setStep] = useState<'ask' | 'yes' | 'no' | 'thanks'>('ask');
  const [reason, setReason] = useState('');
  const [text, setText] = useState('');
  const busyRef = useRef(busy);
  busyRef.current = busy;

  useEffect(() => {
    try {
      const last = Number(localStorage.getItem(KEY) || 0);
      if (last && Date.now() - last < 30 * 24 * 3600 * 1000) return; // already answered/dismissed in the last 30 days
    } catch (e) {}
    let timer: any;
    const tryOpen = () => {
      if (busyRef.current || document.hidden) {
        timer = setTimeout(tryOpen, 4000);
        return;
      }
      setOpen(true);
    };
    timer = setTimeout(tryOpen, 10000 + Math.random() * 5000);
    return () => clearTimeout(timer);
  }, []);

  const remember = () => {
    try { localStorage.setItem(KEY, String(Date.now())); } catch (e) {}
  };
  const send = (rating: string, why = '', msg = '') => {
    remember();
    try {
      const body = new URLSearchParams({
        'form-name': 'feedback',
        rating,
        reason: why,
        message: msg,
        page: window.location.pathname,
        device: window.matchMedia('(max-width: 767px)').matches ? 'mobile' : 'desktop',
      }).toString();
      fetch('/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body }).catch(() => {});
    } catch (e) {}
  };
  const close = () => {
    remember();
    setOpen(false);
  };
  const share = async () => {
    const data = { title: 'ZappImg Pro', text: 'Free image tools that run privately in your browser.', url: window.location.origin };
    try {
      if ((navigator as any).share) await (navigator as any).share(data);
      else await navigator.clipboard.writeText(data.url);
    } catch (e) {}
    setStep('thanks');
    setTimeout(() => setOpen(false), 2200);
  };

  if (!open) return null;
  return (
    <div
      role="dialog"
      aria-label="Website feedback"
      className="fixed z-[75] left-3 right-3 sm:left-6 sm:right-auto sm:w-[360px] zv-pop"
      style={{ bottom: 'calc(96px + env(safe-area-inset-bottom, 0px))' }}
    >
      <div className="rounded-3xl bg-white/95 backdrop-blur-xl border border-[#E7E2D8] shadow-[0_24px_60px_-20px_rgba(20,23,31,.5)] p-5 relative">
        <button type="button" onClick={close} aria-label="Close" className="absolute top-3 right-3 w-8 h-8 rounded-full bg-[#F7F5F0] text-[#6B7080] text-sm font-bold">✕</button>

        {step === 'ask' && (
          <>
            <div className="text-lg font-extrabold text-[#14171F] pr-8">Are you liking this website?</div>
            <p className="text-xs text-[#6B7080] mt-1">It takes 3 seconds and helps us improve.</p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <button type="button" onClick={() => { send('yes'); setStep('yes'); }} className="py-3 rounded-2xl bg-[#0F766E] text-white font-extrabold text-sm">👍 Yes, love it</button>
              <button type="button" onClick={() => setStep('no')} className="py-3 rounded-2xl bg-[#F7F5F0] border border-[#E7E2D8] text-[#14171F] font-extrabold text-sm">👎 Not really</button>
            </div>
          </>
        )}

        {step === 'yes' && (
          <>
            <div className="text-lg font-extrabold text-[#14171F] pr-8">Glad to hear it! 🎉</div>
            <p className="text-xs text-[#6B7080] mt-1">Know someone who edits photos? Send them the link.</p>
            <div className="mt-4 flex gap-2">
              <button type="button" onClick={share} className="flex-1 py-3 rounded-2xl bg-[#14171F] text-white font-extrabold text-sm">Share ZappImg Pro</button>
              <button type="button" onClick={() => setOpen(false)} className="px-4 py-3 rounded-2xl bg-[#F7F5F0] border border-[#E7E2D8] font-bold text-sm">Later</button>
            </div>
          </>
        )}

        {step === 'no' && (
          <>
            <div className="text-lg font-extrabold text-[#14171F] pr-8">Sorry! What went wrong?</div>
            <div className="mt-3 flex flex-wrap gap-2">
              {REASONS.map((r) => (
                <button key={r} type="button" onClick={() => setReason(r)} className={`px-3 py-1.5 rounded-full text-xs font-bold border ${reason === r ? 'bg-[#C2410C] text-white border-[#C2410C]' : 'bg-white border-[#E7E2D8] text-[#14171F]'}`}>{r}</button>
              ))}
            </div>
            <textarea value={text} onChange={(e) => setText(e.target.value.slice(0, 400))} rows={2} placeholder="Anything else? (optional)" className="mt-3 w-full rounded-2xl border border-[#E7E2D8] bg-[#F7F5F0] p-3 text-sm" />
            <button
              type="button"
              onClick={() => { send('no', reason, text); setStep('thanks'); setTimeout(() => setOpen(false), 2200); }}
              className="mt-3 w-full py-3 rounded-2xl bg-[#14171F] text-white font-extrabold text-sm"
            >
              Send feedback
            </button>
          </>
        )}

        {step === 'thanks' && (
          <div className="py-3 text-center">
            <div className="text-3xl">🙏</div>
            <div className="mt-1 text-lg font-extrabold text-[#14171F]">Thank you!</div>
            <p className="text-xs text-[#6B7080]">Your feedback makes ZappImg Pro better.</p>
          </div>
        )}
      </div>
    </div>
  );
};

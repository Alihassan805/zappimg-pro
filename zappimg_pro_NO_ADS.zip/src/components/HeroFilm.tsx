import React, { useEffect, useRef, useState } from 'react';

/**
 * Cinematic hero film (12 s loop, 520 KB). Performance-first:
 *  - the poster image shows instantly; the video only starts downloading AFTER the page has loaded and the browser is idle
 *  - phones get a smaller 480p file
 *  - plays only while visible (saves battery/data), respects "reduce motion", has a pause button
 */
export const HeroFilm: React.FC = () => {
  const vref = useRef<HTMLVideoElement>(null);
  const boxRef = useRef<HTMLDivElement>(null);
  const [load, setLoad] = useState(false);
  const [ready, setReady] = useState(false);
  const [paused, setPaused] = useState(false);
  const [small, setSmall] = useState(false);
  const reduced = typeof window !== 'undefined' && window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  useEffect(() => {
    setSmall(window.matchMedia('(max-width: 700px)').matches);
    if (reduced) return;
    const w: any = window;
    const go = () => (w.requestIdleCallback ? w.requestIdleCallback(() => setLoad(true), { timeout: 3000 }) : setTimeout(() => setLoad(true), 1500));
    if (document.readyState === 'complete') go();
    else window.addEventListener('load', go, { once: true });
    return () => window.removeEventListener('load', go);
  }, [reduced]);

  useEffect(() => {
    const v = vref.current;
    const box = boxRef.current;
    if (!v || !box || !load) return;
    v.muted = true;
    v.defaultMuted = true;
    const io = new IntersectionObserver(
      (entries) => {
        const vis = entries.some((e) => e.isIntersecting);
        if (vis && !paused) v.play().catch(() => {});
        else v.pause();
      },
      { threshold: 0.25 }
    );
    io.observe(box);
    return () => io.disconnect();
  }, [load, paused]);

  const toggle = () => {
    const v = vref.current;
    if (!v) return;
    if (v.paused) {
      setPaused(false);
      v.play().catch(() => {});
    } else {
      setPaused(true);
      v.pause();
    }
  };

  return (
    <div className="mt-10 mx-auto max-w-5xl">
      <div
        ref={boxRef}
        className="relative aspect-video rounded-[22px] sm:rounded-[30px] overflow-hidden bg-[#0C0E13] border border-[#1D2230] shadow-[0_40px_80px_-34px_rgba(20,23,31,.65)]"
      >
        <img
          src="/hero-film-poster.jpg"
          width={1280}
          height={720}
          alt="ZappImg Pro in action: drop a photo, remove the background in one click, export every size"
          loading="lazy"
          decoding="async"
          className="absolute inset-0 w-full h-full object-cover"
        />
        {load && !reduced && (
          <video
            ref={vref}
            src={small ? '/hero-film-sm.mp4' : '/hero-film.mp4'}
            poster="/hero-film-poster.jpg"
            muted
            loop
            playsInline
            preload="auto"
            aria-hidden="true"
            onPlaying={() => setReady(true)}
            className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-700 ${ready ? 'opacity-100' : 'opacity-0'}`}
          />
        )}
        {!reduced && load && (
          <button
            type="button"
            onClick={toggle}
            aria-label={paused ? 'Play hero film' : 'Pause hero film'}
            className="absolute bottom-3 right-3 w-9 h-9 rounded-full bg-black/45 backdrop-blur text-white text-xs font-bold flex items-center justify-center hover:bg-black/70"
          >
            {paused ? '▶' : '❚❚'}
          </button>
        )}
      </div>
    </div>
  );
};

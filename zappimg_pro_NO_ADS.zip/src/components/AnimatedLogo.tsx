import React, { useId } from 'react';

/**
 * Premium animated ZappImg logo (pure SVG + CSS, no images, ~1 KB):
 *  - a light sweep glides across the lightning bolt
 *  - the bolt breathes with a soft orange glow
 *  - the white "pixel" blinks like a processed pixel
 * Animations are disabled automatically for users who prefer reduced motion.
 */
export const AnimatedLogo: React.FC<{ className?: string }> = ({ className = 'w-8 h-8' }) => {
  const uid = useId().replace(/[^a-zA-Z0-9]/g, '');
  const gradId = `zlg${uid}`;
  const clipId = `zlc${uid}`;
  const bolt = '18,4 8,17 15,17 12,28 24,14 17,14';
  return (
    <svg className={`zl-logo ${className}`} viewBox="0 0 32 32" fill="none" aria-hidden="true">
      <defs>
        <linearGradient id={gradId} x1="8" y1="4" x2="24" y2="28" gradientUnits="userSpaceOnUse">
          <stop offset="0" stopColor="#FFC15A" />
          <stop offset="0.55" stopColor="#FF7A1A" />
          <stop offset="1" stopColor="#E8480C" />
        </linearGradient>
        <clipPath id={clipId}>
          <polygon points={bolt} />
        </clipPath>
      </defs>
      <rect width="32" height="32" rx="9" fill="#14171F" />
      <rect className="zl-ring" x="0.75" y="0.75" width="30.5" height="30.5" rx="8.5" stroke="#FF7A1A" strokeOpacity="0.35" strokeWidth="1.2" />
      <polygon className="zl-bolt" points={bolt} fill={`url(#${gradId})`} />
      <g clipPath={`url(#${clipId})`}>
        <g transform="skewX(-18)">
          <rect className="zl-sweep" x="-14" y="0" width="5" height="32" fill="#FFFFFF" opacity="0.7" />
        </g>
      </g>
      <rect className="zl-pixel" x="22" y="22" width="5" height="5" rx="1" fill="#FFFFFF" />
    </svg>
  );
};

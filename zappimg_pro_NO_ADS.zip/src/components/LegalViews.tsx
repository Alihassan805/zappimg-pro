import React from 'react';

export type LegalRoute = 'privacy' | 'terms' | 'cookies' | 'security';

interface LegalViewsProps {
  route: LegalRoute;
  onBack: () => void;
}

export const LEGAL_METADATA: Record<LegalRoute, { title: string; desc: string; canonical: string }> = {
  privacy: {
    title: 'Privacy Policy & Zero-Cloud Guarantee - ZappImg Pro',
    desc: 'Our zero-cloud, 100% client-side privacy architecture. Your photos, biometric IDs, and documents never leave your local device.',
    canonical: '/#privacy',
  },
  terms: {
    title: 'Terms of Service - ZappImg Pro',
    desc: 'Terms of service for ZappImg Pro client-side web application. Commercial usage rights, licensing, and offline processing warranties.',
    canonical: '/#terms',
  },
  cookies: {
    title: 'Cookie Policy & Local Storage Transparency - ZappImg Pro',
    desc: 'Zero tracking cookies and absolute privacy. Detailed overview of how local storage is used exclusively for recent preset preferences.',
    canonical: '/#cookies',
  },
  security: {
    title: 'Security Architecture & Air-Gapped Processing - ZappImg Pro',
    desc: 'Technical whitepaper on client-side sandboxing, WebAssembly memory safety, and zero external transmission verification.',
    canonical: '/#security',
  },
};

export const LegalViews: React.FC<LegalViewsProps> = ({ route, onBack }) => {
  return (
    <div className="max-w-[1000px] mx-auto px-4 sm:px-6 py-12">
      {/* Back button header */}
      <div className="mb-8 flex items-center justify-between border-b border-[#E7E2D8] pb-4">
        <button
          type="button"
          onClick={onBack}
          className="inline-flex items-center gap-2 text-xs font-bold text-[#0F766E] hover:text-[#115E59] transition-colors"
        >
          <span>←</span> Back to Image Tools
        </button>
        <span className="text-[11px] font-semibold text-[#6B7080]">
          Last reviewed: October 2026 · Client-Side Certified
        </span>
      </div>

      {route === 'privacy' && (
        <article className="prose prose-slate max-w-none text-[#4B5160] space-y-6 text-sm leading-relaxed">
          <div className="border-b border-[#E7E2D8] pb-4">
            <span className="text-xs uppercase font-extrabold tracking-wider text-[#0F766E]">Official Policy</span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#14171F] mt-1">
              Privacy Policy &amp; Zero-Cloud Guarantee
            </h1>
            <p className="text-xs text-[#6B7080] mt-1">
              Document reference: ZAPP-PRIV-2026.04 · Effective globally across all web visitors.
            </p>
          </div>

          <div className="bg-[#ECFDF5] border border-[#A7F3D0] rounded-xl p-4 text-[#065F46] font-medium text-xs">
            <strong>Executive Summary:</strong> ZappImg Pro does not operate remote processing servers, database endpoints, or telemetry collectors for your image files. When you compress, resize, or convert photos on this website, all calculations occur solely within your device&rsquo;s CPU, GPU, and WebAssembly memory registers.
          </div>

          <h2 className="text-lg font-bold text-[#14171F]">1. Complete Absence of Server Uploads</h2>
          <p>
            Unlike conventional SaaS photo editors that stream user images over HTTP/HTTPS to cloud clusters for rendering, ZappImg Pro executes entirely within the browser sandbox via the HTML5 Canvas 2D API, OffscreenCanvas, Web Workers, and WebAssembly. Your photos, biometric identity documents, family pictures, and proprietary screenshots are never uploaded, buffered, indexed, or stored on any remote cloud machine.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">2. Sensitive EXIF &amp; GPS Location Data</h2>
          <p>
            Modern smartphone and DSLR camera files embed extensive Exchangeable Image File Format (EXIF) metadata, including precise latitude and longitude GPS coordinates, camera serial numbers, lens models, and timestamps. By default, ZappImg Pro purges all APP1 metadata headers upon re-encoding, ensuring that images you publish to web portals or social media cannot be reverse-engineered to track your physical whereabouts or capture date. If you explicitly activate the &ldquo;Keep EXIF Metadata&rdquo; toggle, the original binary marker is preserved strictly within the client-side exported blob.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">3. Zero Biometric Data Retention</h2>
          <p>
            When utilizing the Passport &amp; ID Maker or Background Remover, facial detection and head-oval framing run through mathematical geometry checks in local memory. At no point are facial geometry vectors, facial embeddings, or biometric templates computed for identity matching or transmitted to third parties.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">4. Network Transparency &amp; Verification</h2>
          <p>
            You are actively encouraged to verify our zero-transmission architecture using your browser&rsquo;s Developer Tools (Press F12 &rarr; Network tab). When loading, resizing, compressing 100 images, or compiling PDFs, zero byte payloads containing file bytes leave your computer. You can disconnect your Wi-Fi or enable Airplane Mode after initial page delivery, and all 10 tools will continue executing with complete functionality.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">5. Third-Party CDN Dependencies &amp; Monetization</h2>
          <p>
            Static interface scripts and typography are delivered through trusted high-availability CDNs (such as Google Fonts and cdnjs). If Google AdSense is active on standard editorial articles, advertising slots operate under standard Google Publisher policies without accessing or reading user file memory.
          </p>
        </article>
      )}

      {route === 'terms' && (
        <article className="prose prose-slate max-w-none text-[#4B5160] space-y-6 text-sm leading-relaxed">
          <div className="border-b border-[#E7E2D8] pb-4">
            <span className="text-xs uppercase font-extrabold tracking-wider text-[#0F766E]">Legal Terms</span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#14171F] mt-1">
              Terms of Service &amp; Commercial Usage Rights
            </h1>
            <p className="text-xs text-[#6B7080] mt-1">
              Document reference: ZAPP-TERMS-2026.02 · Applicable to personal, agency, and enterprise use.
            </p>
          </div>

          <h2 className="text-lg font-bold text-[#14171F]">1. Grant of License &amp; Full Commercial Freedom</h2>
          <p>
            ZappImg Pro grants you an irrevocable, worldwide, royalty-free license to use the application for both personal and commercial operations. You retain 100% full intellectual property ownership, copyright, and moral rights to all images, graphics, and documents processed through this tool. No copyright transfer, watermark requirement, or licensing attribution is ever demanded.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">2. Passport &amp; Identity Document Disclaimer</h2>
          <p>
            The Passport &amp; ID Maker utility provides precision pixel dimensions and standard sizing ratios (such as US Department of State 2&times;2 in and UK HM Passport Office 35&times;45 mm) to assist in framing. However, international consulates and government agencies maintain strict biometric guidelines regarding background lighting, facial expressions, eye wear, shadows, and print paper stock. It is the user&rsquo;s sole responsibility to ensure that printed submissions comply with their respective consulate or national passport authority requirements.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">3. Performance &amp; Client-Side Hardware Utilization</h2>
          <p>
            Because all processing workloads (including multi-file Lanczos-3 interpolation, ZIP compression, and PDF rendering) execute on the client device, performance depends directly on your device&rsquo;s available CPU, GPU acceleration, and system RAM. ZappImg Pro implements memory management safety rails to prevent tab crashes; however, processing hundreds of 8K images simultaneously on low-memory mobile hardware may result in browser throttling.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">4. Limitation of Liability &amp; Warranty</h2>
          <p>
            The service is delivered &ldquo;as-is&rdquo; without warranties of any kind, whether express, implied, or statutory. In no event shall the creators or maintainers of ZappImg Pro be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of the application or loss of local file data. We recommend always retaining an original backup of master photography before running destructive local operations.
          </p>
        </article>
      )}

      {route === 'cookies' && (
        <article className="prose prose-slate max-w-none text-[#4B5160] space-y-6 text-sm leading-relaxed">
          <div className="border-b border-[#E7E2D8] pb-4">
            <span className="text-xs uppercase font-extrabold tracking-wider text-[#0F766E]">Compliance &amp; Storage</span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#14171F] mt-1">
              Cookie Policy &amp; Local Storage Transparency
            </h1>
            <p className="text-xs text-[#6B7080] mt-1">
              Compliance standards: ePrivacy Directive (EU), GDPR Art. 5, CCPA / CPRA transparent storage.
            </p>
          </div>

          <h2 className="text-lg font-bold text-[#14171F]">1. Zero First-Party Tracking Cookies</h2>
          <p>
            ZappImg Pro does not set persistent tracking cookies, cross-site beacons, fingerprinting hashes, or user profiling identifiers. We believe that privacy-preserving utility software should function without demanding behavioral surveillance.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">2. How We Utilize Browser LocalStorage</h2>
          <p>
            To deliver an optimal user experience across consecutive visits, ZappImg Pro stores a minimal set of non-identifying operational preferences in your browser&rsquo;s HTML5 localStorage sandbox:
          </p>
          <ul className="list-disc pl-5 space-y-1.5 text-xs">
            <li><code className="bg-gray-100 px-1 py-0.5 rounded font-mono">zapp_recent_presets</code>: Stores up to 6 recently selected preset IDs (e.g., Instagram Post, YouTube Thumbnail) to render the 1-click &ldquo;Recently Used&rdquo; toolbar.</li>
            <li><code className="bg-gray-100 px-1 py-0.5 rounded font-mono">zapp_region</code>: Remembers whether you preferred US Imperial (inches) or UK Metric (mm) document standards.</li>
            <li><code className="bg-gray-100 px-1 py-0.5 rounded font-mono">zapp_cookie_dismissed</code>: Flags whether you acknowledged the on-device processing notification banner.</li>
          </ul>
          <p>
            This data never leaves your device and can be erased instantly at any time by clearing your browser cache or invoking <code className="bg-gray-100 px-1 py-0.5 rounded font-mono">localStorage.clear()</code> in your browser console.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">3. Third-Party Advertising Cookies</h2>
          <p>
            When viewing informational guides or editorial articles where Google AdSense slots are loaded, Google and its certified ad technology partners may place third-party cookies to serve personalized or non-personalized advertisements based on your prior visits to other internet domains. You can manage your personalized ad preferences through Google Ad Settings or the Digital Advertising Alliance consumer opt-out portal.
          </p>
        </article>
      )}

      {route === 'security' && (
        <article className="prose prose-slate max-w-none text-[#4B5160] space-y-6 text-sm leading-relaxed">
          <div className="border-b border-[#E7E2D8] pb-4">
            <span className="text-xs uppercase font-extrabold tracking-wider text-[#0F766E]">Technical Whitepaper</span>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-[#14171F] mt-1">
              Security Architecture &amp; Air-Gapped Verification
            </h1>
            <p className="text-xs text-[#6B7080] mt-1">
              Cryptographic design review: Zero-knowledge memory allocation and client isolation.
            </p>
          </div>

          <h2 className="text-lg font-bold text-[#14171F]">1. Sandboxed In-Memory Processing</h2>
          <p>
            When an image or document is dragged into ZappImg Pro, the file is accessed via the browser&rsquo;s native File API using memory-mapped object URLs (<code className="bg-gray-100 px-1 py-0.5 rounded font-mono">URL.createObjectURL</code>). The raw bytes are decoded directly into an isolated Canvas pixel buffer in hardware memory. Because processing executes exclusively inside the client-side JavaScript V8/SpiderMonkey sandbox, files cannot interact with unauthorized operating system processes or external network sockets.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">2. Air-Gapped &amp; Offline Operation</h2>
          <p>
            The complete code bundle for image resizing, compression, ZIP archiving, and PDF compilation is self-contained. Once the page is loaded into your browser cache, you can disconnect your machine from the internet (enabling full air-gap isolation). This makes ZappImg Pro uniquely compliant with enterprise and institutional data compliance policies where sensitive photos, medical scans, or internal confidential schematics are strictly forbidden from touching external servers.
          </p>

          <h2 className="text-lg font-bold text-[#14171F]">3. Memory Hygiene &amp; Revocation</h2>
          <p>
            Whenever a file is removed from the shared tray or when the tray is cleared, ZappImg Pro explicitly invokes <code className="bg-gray-100 px-1 py-0.5 rounded font-mono">URL.revokeObjectURL()</code> to instruct the browser garbage collector to deallocate the binary heap buffer immediately. This prevents memory leaks and ensures that image data does not linger in browser memory after your session concludes.
          </p>
        </article>
      )}

      <div className="mt-12 pt-6 border-t border-[#E7E2D8] flex items-center justify-between">
        <button
          type="button"
          onClick={onBack}
          className="px-5 py-2.5 bg-[#14171F] hover:bg-black text-white text-xs font-bold rounded-xl transition-colors shadow-xs"
        >
          ← Return to Workspace
        </button>
        <span className="text-xs text-[#6B7080]">ZappImg Pro · 100% Client-Side Engine</span>
      </div>
    </div>
  );
};

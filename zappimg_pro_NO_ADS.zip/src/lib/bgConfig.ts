/**
 * Model configuration (shared by the worker and the UI).
 *
 * LICENSE NOTE
 *   'modnet'  -> Xenova/modnet (MODNet, Apache-2.0). Safe for commercial / ad-supported sites. Best on people.
 *   'rmbg14'  -> briaai/RMBG-1.4. Better on products BUT NON-COMMERCIAL unless you hold a Bria licence.
 */
export type BgModelKey = 'modnet' | 'rmbg14';
export const BG_MODEL: BgModelKey = 'modnet';

export const MODELS: Record<BgModelKey, { id: string; modelOpts: any; processorOpts: any }> = {
  modnet: { id: 'Xenova/modnet', modelOpts: {}, processorOpts: {} },
  rmbg14: {
    id: 'briaai/RMBG-1.4',
    modelOpts: { config: { model_type: 'custom' } },
    processorOpts: {
      config: {
        do_normalize: true,
        do_pad: false,
        do_rescale: true,
        do_resize: true,
        image_mean: [0.5, 0.5, 0.5],
        feature_extractor_type: 'ImageFeatureExtractor',
        image_std: [1, 1, 1],
        resample: 2,
        rescale_factor: 0.00392156862745098,
        size: { width: 1024, height: 1024 },
      },
    },
  },
};

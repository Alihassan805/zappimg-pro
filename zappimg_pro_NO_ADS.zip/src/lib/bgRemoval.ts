/**
 * ZappImg Pro – in-browser AI background removal (main-thread side).
 * The real work happens in ./bgWorker.ts (Web Worker) so the page NEVER freezes.
 * Public API is unchanged: loadBgEngine / removeBackgroundBatch / pickQuality.
 */
export interface BgEngine {
  worker: Worker;
  device: 'webgpu' | 'wasm';
  request: (blob: Blob, inferSide: number, maxOutSide: number, bgColor: string) => Promise<Blob>;
}

export type EngineProgress = (percent: number, label: string) => void;

let enginePromise: Promise<BgEngine> | null = null;
let progressListeners: EngineProgress[] = [];

export function loadBgEngine(onProgress?: EngineProgress): Promise<BgEngine> {
  if (onProgress) progressListeners.push(onProgress);
  if (enginePromise) return enginePromise;

  enginePromise = new Promise<BgEngine>((resolve, reject) => {
    let worker: Worker;
    try {
      worker = new Worker(new URL('./bgWorker.ts', import.meta.url), { type: 'module' });
    } catch (e) {
      reject(new Error('Your browser does not support background workers.'));
      return;
    }

    let nextId = 1;
    const pending = new Map<number, { resolve: (b: Blob) => void; reject: (e: Error) => void }>();
    let ready = false;

    const failAll = (message: string) => {
      pending.forEach((p) => p.reject(new Error(message)));
      pending.clear();
    };

    worker.onmessage = (e: MessageEvent) => {
      const m: any = e.data;
      if (m.type === 'progress') {
        progressListeners.forEach((fn) => fn(m.percent, m.label));
      } else if (m.type === 'ready') {
        ready = true;
        progressListeners.forEach((fn) => fn(100, 'AI model ready'));
        resolve({
          worker,
          device: m.device,
          request: (blob, inferSide, maxOutSide, bgColor) =>
            new Promise<Blob>((res, rej) => {
              const id = nextId++;
              pending.set(id, { resolve: res, reject: rej });
              worker.postMessage({ type: 'infer', id, blob, inferSide, maxOutSide, bgColor });
            }),
        });
      } else if (m.type === 'error') {
        if (!ready) reject(new Error(m.message || 'AI model failed to load'));
        else failAll(m.message || 'AI error');
      } else if (m.type === 'result') {
        pending.get(m.id)?.resolve(m.blob);
        pending.delete(m.id);
      } else if (m.type === 'itemError') {
        pending.get(m.id)?.reject(new Error(m.message || 'Image failed'));
        pending.delete(m.id);
      }
    };
    worker.onerror = (ev) => {
      const msg = (ev && (ev as any).message) || 'AI worker crashed';
      if (!ready) reject(new Error(msg));
      else failAll(msg);
    };
    worker.postMessage({ type: 'init' });
  });

  // If loading fails (offline, blocked CDN) allow a clean retry next time.
  enginePromise.catch(() => {
    enginePromise = null;
    progressListeners = [];
  });
  return enginePromise;
}

export interface BatchOptions {
  bgColor: string; // 'transparent' or CSS colour
  signal?: AbortSignal;
  onItemDone?: (index: number, blob: Blob) => void;
  onItemError?: (index: number, err: any) => void;
  onTick?: (done: number, total: number, avgMsPerImage: number) => void;
}

/** Single image -> best quality. Big batches -> automatically lighter so the batch stays fast. */
export function pickQuality(count: number) {
  if (count <= 1) return { inferSide: 1024, maxOutSide: 4096 };
  if (count <= 10) return { inferSide: 896, maxOutSide: 3600 };
  if (count <= 40) return { inferSide: 768, maxOutSide: 3000 };
  return { inferSide: 640, maxOutSide: 2560 };
}

export async function removeBackgroundBatch(engine: BgEngine, files: Blob[], opts: BatchOptions): Promise<void> {
  const q = pickQuality(files.length);
  const started = performance.now();
  const total = files.length;
  const inflight = new Map<number, Promise<Blob>>();
  let nextToSend = 0;
  let done = 0;

  for (let i = 0; i < total; i++) {
    if (opts.signal?.aborted) return;
    // keep 2 images queued in the worker so it never sits idle
    while (nextToSend < total && nextToSend < i + 2) {
      const p = engine.request(files[nextToSend], q.inferSide, q.maxOutSide, opts.bgColor);
      p.catch(() => {});
      inflight.set(nextToSend, p);
      nextToSend++;
    }
    try {
      const blob = await inflight.get(i)!;
      if (opts.signal?.aborted) return;
      opts.onItemDone?.(i, blob);
    } catch (err) {
      opts.onItemError?.(i, err);
    }
    inflight.delete(i);
    done++;
    opts.onTick?.(done, total, (performance.now() - started) / done);
  }
}

/// <reference lib="webworker" />
/**
 * Background-removal Web Worker.
 * ALL heavy work (model download/initialisation, decoding, neural-net inference, compositing and PNG encoding)
 * runs here, so the page never freezes – not even while the model is being prepared.
 */
import { AutoModel, AutoProcessor, RawImage, env } from '@huggingface/transformers';
import { BG_MODEL, MODELS } from './bgConfig';

const ctx: any = self;
let model: any = null;
let processor: any = null;
let device: 'webgpu' | 'wasm' = 'wasm';
let initPromise: Promise<void> | null = null;

const CURVE = (() => {
  const t = new Uint8ClampedArray(256);
  const lo = 0.1;
  const hi = 0.9;
  for (let i = 0; i < 256; i++) {
    const x = Math.min(1, Math.max(0, (i / 255 - lo) / (hi - lo)));
    t[i] = Math.round(x * x * (3 - 2 * x) * 255);
  }
  return t;
})();

function post(msg: any) {
  ctx.postMessage(msg);
}

async function init() {
  if (initPromise) return initPromise;
  initPromise = (async () => {
    env.allowLocalModels = false;
    env.useBrowserCache = true;
    const cfg = MODELS[BG_MODEL];
    const files: Record<string, { loaded: number; total: number }> = {};
    let lastPct = -1;
    const progress_callback = (p: any) => {
      if (!p) return;
      if (p.status === 'progress' && p.file) {
        files[p.file] = { loaded: p.loaded || 0, total: p.total || 0 };
        let loaded = 0;
        let total = 0;
        for (const k of Object.keys(files)) {
          loaded += files[k].loaded;
          total += files[k].total;
        }
        if (total > 0) {
          const pct = Math.min(95, Math.round((loaded / total) * 95));
          if (pct !== lastPct) {
            lastPct = pct;
            post({ type: 'progress', percent: pct, label: 'Downloading AI model (one-time)…' });
          }
        }
      } else if (p.status === 'done') {
        post({ type: 'progress', percent: 96, label: 'Starting AI engine…' });
      }
    };

    const hasWebGPU = typeof (self as any).navigator !== 'undefined' && !!(self as any).navigator.gpu;
    const attempts: { device: 'webgpu' | 'wasm'; dtype: string }[] = [];
    if (hasWebGPU) attempts.push({ device: 'webgpu', dtype: 'fp32' });
    attempts.push({ device: 'wasm', dtype: 'q8' });
    attempts.push({ device: 'wasm', dtype: 'fp32' });

    let lastErr: any = null;
    for (const a of attempts) {
      try {
        model = await AutoModel.from_pretrained(cfg.id, {
          ...cfg.modelOpts,
          device: a.device,
          dtype: a.dtype,
          progress_callback,
        } as any);
        device = a.device;
        break;
      } catch (e) {
        lastErr = e;
        model = null;
      }
    }
    if (!model) throw lastErr || new Error('Could not load the AI model.');
    processor = await AutoProcessor.from_pretrained(cfg.id, cfg.processorOpts);

    // Warm-up: one tiny dummy run so the FIRST real photo is not slow (shader / graph compilation happens here)
    try {
      post({ type: 'progress', percent: 98, label: 'Warming up AI engine…' });
      const c = new OffscreenCanvas(64, 64);
      const g = c.getContext('2d')!;
      g.fillStyle = '#888';
      g.fillRect(0, 0, 64, 64);
      const d = g.getImageData(0, 0, 64, 64);
      const raw = new RawImage(d.data as any, 64, 64, 4).rgb();
      const { pixel_values } = await processor(raw);
      await model({ input: pixel_values });
    } catch (e) {
      /* warm-up is optional */
    }
    post({ type: 'ready', device });
  })();
  return initPromise;
}

async function run(blob: Blob, inferSide: number, maxOutSide: number, bgColor: string): Promise<Blob> {
  if (typeof OffscreenCanvas === 'undefined') {
    throw new Error('This browser is too old for Auto (AI). Please update it or use Manual mode.');
  }
  const bitmap = await createImageBitmap(blob);
  const long = Math.max(bitmap.width, bitmap.height);
  const outScale = long > maxOutSide ? maxOutSide / long : 1;
  const outW = Math.max(1, Math.round(bitmap.width * outScale));
  const outH = Math.max(1, Math.round(bitmap.height * outScale));
  const inScale = long > inferSide ? inferSide / long : 1;
  const iw = Math.max(1, Math.round(bitmap.width * inScale));
  const ih = Math.max(1, Math.round(bitmap.height * inScale));

  const c = new OffscreenCanvas(iw, ih);
  const g = c.getContext('2d', { willReadFrequently: true })!;
  g.imageSmoothingQuality = 'high';
  g.drawImage(bitmap, 0, 0, iw, ih);
  const data = g.getImageData(0, 0, iw, ih);
  const raw = new RawImage(data.data as any, iw, ih, 4).rgb();
  const { pixel_values } = await processor(raw);
  const out = await model({ input: pixel_values });
  const output = (out as any).output ?? (Object.values(out)[0] as any);
  const maskImg: any = RawImage.fromTensor(output[0].mul(255).to('uint8'));
  const mw: number = maskImg.width;
  const mh: number = maskImg.height;
  const md: ArrayLike<number> = maskImg.data;
  const channels: number = maskImg.channels || 1;

  const mc = new OffscreenCanvas(mw, mh);
  const mctx = mc.getContext('2d')!;
  const mdata = mctx.createImageData(mw, mh);
  for (let i = 0, p = 0; i < mw * mh; i++, p += 4) {
    mdata.data[p + 3] = CURVE[md[i * channels]];
  }
  mctx.putImageData(mdata, 0, 0);

  const oc = new OffscreenCanvas(outW, outH);
  const octx = oc.getContext('2d')!;
  octx.imageSmoothingEnabled = true;
  octx.imageSmoothingQuality = 'high';
  octx.drawImage(bitmap, 0, 0, outW, outH);
  octx.globalCompositeOperation = 'destination-in';
  octx.drawImage(mc, 0, 0, outW, outH);
  if (bgColor && bgColor !== 'transparent') {
    octx.globalCompositeOperation = 'destination-over';
    octx.fillStyle = bgColor;
    octx.fillRect(0, 0, outW, outH);
  }
  bitmap.close?.();
  return await oc.convertToBlob({ type: 'image/png' });
}

// Process one image at a time inside the worker (the GPU/WASM session is not re-entrant)
let chain: Promise<void> = Promise.resolve();

ctx.onmessage = (e: MessageEvent) => {
  const msg: any = e.data;
  if (msg.type === 'init') {
    init().catch((err) => post({ type: 'error', message: (err && err.message) || String(err) }));
  } else if (msg.type === 'infer') {
    chain = chain.then(async () => {
      try {
        await init();
        const blob = await run(msg.blob, msg.inferSide, msg.maxOutSide, msg.bgColor);
        post({ type: 'result', id: msg.id, blob });
      } catch (err: any) {
        post({ type: 'itemError', id: msg.id, message: (err && err.message) || String(err) });
      }
    });
  }
};

/** Lifetime, on-device usage stats (localStorage only – nothing is sent anywhere). */
export interface LifetimeStats {
  images: number;
  bytesSaved: number;
  visits: number;
  firstVisit: number;
  lastVisit: number;
}
const KEY = 'zapp_lifetime_stats';

const blank = (): LifetimeStats => ({ images: 0, bytesSaved: 0, visits: 0, firstVisit: Date.now(), lastVisit: Date.now() });

export function readStats(): LifetimeStats {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return { ...blank(), ...JSON.parse(raw) };
  } catch (e) {}
  return blank();
}

function write(s: LifetimeStats) {
  try {
    localStorage.setItem(KEY, JSON.stringify(s));
  } catch (e) {}
}

/** Call once per page load. Counts a visit at most once every 30 minutes. */
export function bumpVisit(): LifetimeStats {
  const s = readStats();
  if (Date.now() - s.lastVisit > 30 * 60 * 1000 || s.visits === 0) s.visits += 1;
  s.lastVisit = Date.now();
  write(s);
  return s;
}

export function recordWork(images: number, bytesSaved: number): LifetimeStats {
  const s = readStats();
  s.images += images;
  s.bytesSaved += Math.max(0, bytesSaved);
  write(s);
  return s;
}

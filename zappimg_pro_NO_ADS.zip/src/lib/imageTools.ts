/**
 * ZappImg Pro - image engine
 * Everything here runs locally in the browser. No uploads.
 *
 * Fixes the root causes of inaccurate results:
 *  - real pixel size of every photo is measured (it used to be assumed 1200x800)
 *  - EXIF orientation is honoured (phone photos no longer come out sideways)
 *  - real EXIF / GPS is read from the file (it used to show fake "Sony" data)
 *  - crop / rotate / straighten really work and never cut the picture badly
 *  - passport photos are cropped with the head placed correctly (face detection when the browser supports it)
 *  - metadata cleaning keeps the original format (PNG stays PNG, transparency is kept)
 */

export interface ImageInfo {
  width: number;
  height: number;
  /** true when the file could be decoded by this browser */
  ok: boolean;
}

export type Drawable = ImageBitmap | HTMLImageElement | HTMLCanvasElement;

const hasBitmap = typeof createImageBitmap === 'function';

/** Decode a file/blob into something drawable, with EXIF rotation applied. */
export async function decodeBlob(blob: Blob): Promise<Drawable> {
  if (blob.type === 'image/svg+xml' || ((blob as File).name || '').toLowerCase().endsWith('.svg')) {
    blob = await normaliseSvg(blob);
  }
  if (hasBitmap) {
    try {
      return await createImageBitmap(blob, { imageOrientation: 'from-image' } as ImageBitmapOptions);
    } catch {
      /* fall through to <img> */
    }
  }
  const url = URL.createObjectURL(blob);
  try {
    const img = new Image();
    img.decoding = 'async';
    img.src = url;
    if (typeof img.decode === 'function') {
      await img.decode();
    } else {
      await new Promise<void>((res, rej) => {
        img.onload = () => res();
        img.onerror = () => rej(new Error('decode'));
      });
    }
    return img;
  } finally {
    // keep url alive until image is drawn by caller? decode() already finished, safe to revoke later
    setTimeout(() => URL.revokeObjectURL(url), 10000);
  }
}

/** SVGs without width/height decode as 0x0 in some browsers - give them a crisp, real size. */
async function normaliseSvg(blob: Blob): Promise<Blob> {
  try {
    let txt = await blob.text();
    const head = /<svg[^>]*>/i.exec(txt)?.[0] || '';
    const hasW = /\swidth\s*=\s*["'][\d.]+(px)?["']/i.test(head);
    const hasH = /\sheight\s*=\s*["'][\d.]+(px)?["']/i.test(head);
    const vb = /viewBox\s*=\s*["']\s*[-\d.]+[ ,]+[-\d.]+[ ,]+([\d.]+)[ ,]+([\d.]+)/i.exec(head);
    if (head && vb && (!hasW || !hasH)) {
      const vw = parseFloat(vb[1]);
      const vh = parseFloat(vb[2]);
      const k = Math.max(1, 2048 / Math.max(vw, vh));
      const clean = head.replace(/\s(width|height)\s*=\s*["'][^"']*["']/gi, '');
      txt = txt.replace(head, clean.replace(/<svg/i, `<svg width="${Math.round(vw * k)}" height="${Math.round(vh * k)}"`));
      return new Blob([txt], { type: 'image/svg+xml' });
    }
  } catch {
    /* use as is */
  }
  return blob;
}

export function dimsOf(d: Drawable): { w: number; h: number } {
  if (d instanceof HTMLImageElement) return { w: d.naturalWidth, h: d.naturalHeight };
  return { w: (d as any).width, h: (d as any).height };
}

export function releaseDrawable(d: Drawable) {
  try {
    (d as ImageBitmap).close?.();
  } catch {
    /* ignore */
  }
}

/** Measure real size of a file (orientation aware). */
export async function readImageInfo(file: Blob): Promise<ImageInfo> {
  try {
    const d = await decodeBlob(file);
    const { w, h } = dimsOf(d);
    releaseDrawable(d);
    return { width: w, height: h, ok: w > 0 && h > 0 };
  } catch {
    return { width: 0, height: 0, ok: false };
  }
}

export function makeCanvas(w: number, h: number): HTMLCanvasElement {
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(w));
  c.height = Math.max(1, Math.round(h));
  return c;
}

export function canvasToBlob(c: HTMLCanvasElement, mime: string, quality?: number): Promise<Blob> {
  return new Promise((res, rej) => {
    c.toBlob(
      (b) => (b ? res(b) : rej(new Error('Your browser could not encode this image. Try another format.'))),
      mime,
      quality
    );
  });
}

/**
 * High quality down-scaling: step-halving keeps edges sharp and avoids the
 * aliasing / blur of a single big drawImage jump.
 */
export function drawScaled(
  src: Drawable | HTMLCanvasElement,
  sx: number,
  sy: number,
  sw: number,
  sh: number,
  dw: number,
  dh: number
): HTMLCanvasElement {
  dw = Math.max(1, Math.round(dw));
  dh = Math.max(1, Math.round(dh));
  // first copy the source region
  let cur = makeCanvas(sw, sh);
  let cctx = cur.getContext('2d')!;
  cctx.drawImage(src as CanvasImageSource, sx, sy, sw, sh, 0, 0, cur.width, cur.height);
  // halve while the target is less than half of the current size
  while (cur.width / 2 >= dw && cur.height / 2 >= dh) {
    const nw = Math.max(dw, Math.floor(cur.width / 2));
    const nh = Math.max(dh, Math.floor(cur.height / 2));
    const next = makeCanvas(nw, nh);
    const nctx = next.getContext('2d')!;
    nctx.imageSmoothingEnabled = true;
    nctx.imageSmoothingQuality = 'high';
    nctx.drawImage(cur, 0, 0, cur.width, cur.height, 0, 0, nw, nh);
    cur = next;
  }
  if (cur.width === dw && cur.height === dh) return cur;
  const out = makeCanvas(dw, dh);
  const octx = out.getContext('2d')!;
  octx.imageSmoothingEnabled = true;
  octx.imageSmoothingQuality = 'high';
  octx.drawImage(cur, 0, 0, cur.width, cur.height, 0, 0, dw, dh);
  return out;
}

// ---------------------------------------------------------------------------
// EXIF reader (real data)
// ---------------------------------------------------------------------------
export interface RealExif {
  make?: string;
  model?: string;
  date?: string;
  software?: string;
  hasGps: boolean;
  lat?: number;
  lng?: number;
  orientation?: number;
}

function readAscii(dv: DataView, off: number, len: number): string {
  let s = '';
  for (let i = 0; i < len; i++) {
    const ch = dv.getUint8(off + i);
    if (ch === 0) break;
    s += String.fromCharCode(ch);
  }
  return s.trim();
}

export function parseExif(buffer: ArrayBuffer): RealExif | null {
  try {
    const dv = new DataView(buffer);
    if (dv.getUint16(0) !== 0xffd8) return null;
    let off = 2;
    while (off < dv.byteLength - 4) {
      if (dv.getUint8(off) !== 0xff) {
        off++;
        continue;
      }
      const marker = dv.getUint8(off + 1);
      if (marker === 0xda) break; // start of scan
      const len = dv.getUint16(off + 2);
      if (marker === 0xe1 && readAscii(dv, off + 4, 4) === 'Exif') {
        const t = off + 10; // tiff start
        const little = dv.getUint16(t) === 0x4949;
        const u16 = (o: number) => dv.getUint16(o, little);
        const u32 = (o: number) => dv.getUint32(o, little);
        const out: RealExif = { hasGps: false };

        const readIfd = (ifdOff: number, handler: (tag: number, type: number, count: number, valOff: number) => void) => {
          const n = u16(t + ifdOff);
          for (let i = 0; i < n; i++) {
            const e = t + ifdOff + 2 + i * 12;
            if (e + 12 > dv.byteLength) break;
            const tag = u16(e);
            const type = u16(e + 2);
            const count = u32(e + 4);
            const size = (type === 3 ? 2 : type === 4 ? 4 : type === 5 || type === 10 ? 8 : 1) * count;
            const valOff = size > 4 ? t + u32(e + 8) : e + 8;
            handler(tag, type, count, valOff);
          }
        };

        let exifIfd = 0;
        let gpsIfd = 0;
        readIfd(u32(t + 4), (tag, _type, count, vo) => {
          if (tag === 0x010f) out.make = readAscii(dv, vo, count);
          else if (tag === 0x0110) out.model = readAscii(dv, vo, count);
          else if (tag === 0x0131) out.software = readAscii(dv, vo, count);
          else if (tag === 0x0112) out.orientation = u16(vo);
          else if (tag === 0x0132 && !out.date) out.date = readAscii(dv, vo, count);
          else if (tag === 0x8769) exifIfd = u32(vo);
          else if (tag === 0x8825) gpsIfd = u32(vo);
        });
        if (exifIfd) {
          readIfd(exifIfd, (tag, _type, count, vo) => {
            if (tag === 0x9003) out.date = readAscii(dv, vo, count);
          });
        }
        if (gpsIfd) {
          let latRef = 'N';
          let lngRef = 'E';
          let lat: number[] | null = null;
          let lng: number[] | null = null;
          const rat = (o: number) => {
            const d = u32(o + 4);
            return d ? u32(o) / d : 0;
          };
          readIfd(gpsIfd, (tag, _type, _count, vo) => {
            if (tag === 1) latRef = readAscii(dv, vo, 2);
            else if (tag === 3) lngRef = readAscii(dv, vo, 2);
            else if (tag === 2) lat = [rat(vo), rat(vo + 8), rat(vo + 16)];
            else if (tag === 4) lng = [rat(vo), rat(vo + 8), rat(vo + 16)];
          });
          if (lat && lng) {
            const toDeg = (a: number[]) => a[0] + a[1] / 60 + a[2] / 3600;
            out.hasGps = true;
            out.lat = (latRef === 'S' ? -1 : 1) * toDeg(lat);
            out.lng = (lngRef === 'W' ? -1 : 1) * toDeg(lng);
          }
        }
        return out;
      }
      if (len < 2) break;
      off += 2 + len;
    }
  } catch {
    /* corrupt exif */
  }
  return null;
}

// ---------------------------------------------------------------------------
// Format helpers
// ---------------------------------------------------------------------------
export function mimeFor(fmt: string): string {
  switch (fmt) {
    case 'png':
      return 'image/png';
    case 'webp':
      return 'image/webp';
    case 'avif':
      return 'image/avif';
    case 'bmp':
      return 'image/bmp';
    case 'jpg':
    case 'jpeg':
      return 'image/jpeg';
    default:
      return 'image/png';
  }
}

export function extFromMime(m: string): string {
  if (m.includes('png')) return 'png';
  if (m.includes('webp')) return 'webp';
  if (m.includes('avif')) return 'avif';
  if (m.includes('bmp')) return 'bmp';
  if (m.includes('gif')) return 'gif';
  return 'jpg';
}

/** Does this browser really encode that mime? (canvas silently falls back to PNG otherwise) */
export async function canEncode(mime: string): Promise<boolean> {
  if (mime === 'image/png' || mime === 'image/jpeg') return true;
  try {
    const c = makeCanvas(2, 2);
    const b = await canvasToBlob(c, mime, 0.9);
    return b.type === mime;
  } catch {
    return false;
  }
}

/** Make sure a blob has the mime we asked for; otherwise re-encode as the safest alternative. */
export async function encodeCanvas(
  c: HTMLCanvasElement,
  fmt: string,
  quality: number
): Promise<{ blob: Blob; fmt: string }> {
  if (fmt === 'bmp') return { blob: encodeBmp(c), fmt: 'bmp' };
  if (fmt === 'gif') return { blob: encodeGif(c), fmt: 'gif' };
  let mime = mimeFor(fmt);
  let blob = await canvasToBlob(c, mime, quality);
  if (blob.type !== mime) {
    // browser could not encode the requested format -> next best modern format, else lossless PNG
    if (mime !== 'image/webp') {
      const w = await canvasToBlob(c, 'image/webp', quality);
      if (w.type === 'image/webp') return { blob: w, fmt: 'webp' };
    }
    return { blob: await canvasToBlob(c, 'image/png'), fmt: 'png' };
  }
  return { blob, fmt: extFromMime(mime) };
}

/** Paint white behind transparent pixels - only for formats without alpha. */
export function flattenOnColor(c: HTMLCanvasElement, color = '#FFFFFF'): HTMLCanvasElement {
  const out = makeCanvas(c.width, c.height);
  const ctx = out.getContext('2d')!;
  ctx.fillStyle = color;
  ctx.fillRect(0, 0, out.width, out.height);
  ctx.drawImage(c, 0, 0);
  return out;
}

export function formatHasAlpha(fmt: string): boolean {
  return fmt === 'png' || fmt === 'webp' || fmt === 'avif';
}

// ---------------------------------------------------------------------------
// Crop / rotate / straighten
// ---------------------------------------------------------------------------
export function parseRatio(r: string, srcW: number, srcH: number): number | null {
  if (r === 'Free' || r === 'Original') return null;
  const m = /^(\d+(?:\.\d+)?):(\d+(?:\.\d+)?)$/.exec(r);
  if (!m) return null;
  return parseFloat(m[1]) / parseFloat(m[2]);
}

/**
 * Rotate by (rotate90 + straighten) degrees and crop to a ratio.
 * - 90 degree steps swap width/height (nothing gets cut off)
 * - straighten zooms in just enough to remove empty corners
 * - the crop is always the biggest possible area, centred (or on `focus` if given)
 */
export function cropRotate(
  src: Drawable,
  opts: { ratio: number | null; rotate: number; straighten: number; focus?: { x: number; y: number } }
): HTMLCanvasElement {
  const { w, h } = dimsOf(src);
  const quarter = ((Math.round(opts.rotate / 90) % 4) + 4) % 4;
  const rw = quarter % 2 === 1 ? h : w;
  const rh = quarter % 2 === 1 ? w : h;

  // 1) apply 90-degree rotation losslessly
  let base = makeCanvas(rw, rh);
  {
    const ctx = base.getContext('2d')!;
    ctx.translate(rw / 2, rh / 2);
    ctx.rotate((quarter * Math.PI) / 2);
    ctx.drawImage(src as CanvasImageSource, -w / 2, -h / 2);
  }

  // 2) free-angle straighten
  const ang = (opts.straighten * Math.PI) / 180;
  let area = base;
  let aw = rw;
  let ah = rh;
  if (Math.abs(opts.straighten) > 0.01) {
    const cos = Math.abs(Math.cos(ang));
    const sin = Math.abs(Math.sin(ang));
    // largest axis-aligned rectangle of the same ratio that fits inside the rotated image
    const ratioImg = rw / rh;
    const maxW = Math.min(rw / (cos + sin / ratioImg), (rh * ratioImg) / (sin * ratioImg + cos));
    const innerW = Math.max(1, Math.floor(maxW));
    const innerH = Math.max(1, Math.floor(innerW / ratioImg));
    const rot = makeCanvas(innerW, innerH);
    const rctx = rot.getContext('2d')!;
    rctx.imageSmoothingEnabled = true;
    rctx.imageSmoothingQuality = 'high';
    rctx.translate(innerW / 2, innerH / 2);
    rctx.rotate(ang);
    rctx.drawImage(base, -rw / 2, -rh / 2);
    area = rot;
    aw = innerW;
    ah = innerH;
  }

  // 3) crop to ratio (largest possible)
  if (!opts.ratio) return area;
  let cw = aw;
  let ch = Math.round(cw / opts.ratio);
  if (ch > ah) {
    ch = ah;
    cw = Math.round(ch * opts.ratio);
  }
  const fx = opts.focus ? opts.focus.x * aw : aw / 2;
  const fy = opts.focus ? opts.focus.y * ah : ah / 2;
  const cx = Math.min(Math.max(0, Math.round(fx - cw / 2)), aw - cw);
  const cy = Math.min(Math.max(0, Math.round(fy - ch / 2)), ah - ch);
  const out = makeCanvas(cw, ch);
  out.getContext('2d')!.drawImage(area, cx, cy, cw, ch, 0, 0, cw, ch);
  return out;
}

// ---------------------------------------------------------------------------
// Passport / ID photo
// ---------------------------------------------------------------------------
export interface PassportSpec {
  id: string;
  label: string;
  w: number;
  h: number;
  /** head height (chin to crown) as a fraction of photo height */
  headMin: number;
  headMax: number;
  /** distance from top of photo to crown, fraction of photo height */
  topMargin: number;
  /** physical size in millimetres (used for the print sheet) */
  mmW: number;
  mmH: number;
}

export const PASSPORT_SPECS: PassportSpec[] = [
  { id: 'us-2x2', label: 'US Passport (2×2 in / 600×600 px)', w: 600, h: 600, headMin: 0.5, headMax: 0.69, topMargin: 0.12, mmW: 50.8, mmH: 50.8 },
  { id: 'uk-35x45', label: 'UK / EU Passport (35×45 mm / 827×1063 px)', w: 827, h: 1063, headMin: 0.7, headMax: 0.8, topMargin: 0.08, mmW: 35, mmH: 45 },
  { id: 'india-2x2', label: 'India Passport / OCI (2×2 in / 600×600 px)', w: 600, h: 600, headMin: 0.5, headMax: 0.69, topMargin: 0.12, mmW: 50.8, mmH: 50.8 },
  { id: 'canada-50x70', label: 'Canada Passport (50×70 mm / 591×827 px)', w: 591, h: 827, headMin: 0.44, headMax: 0.51, topMargin: 0.1, mmW: 50, mmH: 70 },
  { id: 'au-35x45', label: 'Australia Passport (35×45 mm / 827×1063 px)', w: 827, h: 1063, headMin: 0.7, headMax: 0.8, topMargin: 0.08, mmW: 35, mmH: 45 },
  { id: 'pk-35x45', label: 'Pakistan Passport / CNIC (35×45 mm / 827×1063 px)', w: 827, h: 1063, headMin: 0.65, headMax: 0.8, topMargin: 0.09, mmW: 35, mmH: 45 },
  { id: 'schengen-35x45', label: 'Schengen Visa (35×45 mm / 827×1063 px)', w: 827, h: 1063, headMin: 0.7, headMax: 0.8, topMargin: 0.08, mmW: 35, mmH: 45 },
  { id: 'china-33x48', label: 'China Passport / Visa (33×48 mm / 390×567 px)', w: 390, h: 567, headMin: 0.58, headMax: 0.69, topMargin: 0.1, mmW: 33, mmH: 48 },
  { id: 'id-25x35', label: 'Small ID Card (25×35 mm / 295×413 px)', w: 295, h: 413, headMin: 0.6, headMax: 0.75, topMargin: 0.1, mmW: 25, mmH: 35 },
];

export interface FaceBox {
  x: number;
  y: number;
  w: number;
  h: number;
}

/** Uses the browser's built-in FaceDetector when it exists (Chrome / Edge / Android). */
export async function detectFace(src: Drawable): Promise<FaceBox | null> {
  try {
    const FD = (window as any).FaceDetector;
    if (!FD) return null;
    const det = new FD({ fastMode: false, maxDetectedFaces: 3 });
    const faces: any[] = await det.detect(src as any);
    if (!faces || !faces.length) return null;
    // biggest face
    faces.sort((a, b) => b.boundingBox.width * b.boundingBox.height - a.boundingBox.width * a.boundingBox.height);
    const b = faces[0].boundingBox;
    return { x: b.x, y: b.y, w: b.width, h: b.height };
  } catch {
    return null;
  }
}

/**
 * Builds a passport photo of exact pixel size. With a detected face the head is placed
 * according to the spec; otherwise the photo is cropped from the upper-centre (where heads are).
 * Never stretches the picture.
 */
export async function makePassport(
  src: Drawable,
  spec: PassportSpec,
  bg: string | null,
  face: FaceBox | null
): Promise<{ canvas: HTMLCanvasElement; usedFace: boolean }> {
  const { w, h } = dimsOf(src);
  const ratio = spec.w / spec.h;
  let cw: number;
  let ch: number;
  let cx: number;
  let cy: number;
  let usedFace = false;

  if (face) {
    usedFace = true;
    // BlazeFace-style boxes cover forehead->chin; crown is a little above the box top, hair adds ~25 %.
    const headH = face.h * 1.32;
    const crownY = face.y - face.h * 0.22;
    const targetHead = (spec.headMin + spec.headMax) / 2;
    ch = headH / targetHead;
    cw = ch * ratio;
    cy = crownY - ch * spec.topMargin;
    cx = face.x + face.w / 2 - cw / 2;
  } else {
    // no face info: biggest crop of the right ratio, biased to the top (heads live in the upper part)
    if (w / h > ratio) {
      ch = h;
      cw = h * ratio;
    } else {
      cw = w;
      ch = w / ratio;
    }
    cx = (w - cw) / 2;
    cy = (h - ch) * 0.18;
  }

  // when crop window leaves the photo, shrink instead of stretching, then pad with background colour
  const padColor = bg || '#FFFFFF';
  const out = makeCanvas(spec.w, spec.h);
  const ctx = out.getContext('2d')!;
  ctx.fillStyle = padColor;
  ctx.fillRect(0, 0, out.width, out.height);

  const sx0 = Math.max(0, cx);
  const sy0 = Math.max(0, cy);
  const sx1 = Math.min(w, cx + cw);
  const sy1 = Math.min(h, cy + ch);
  const sw = sx1 - sx0;
  const sh = sy1 - sy0;
  if (sw <= 1 || sh <= 1) {
    // degenerate: fall back to simple centred cover
    const s = Math.max(spec.w / w, spec.h / h);
    const rw2 = spec.w / s;
    const rh2 = spec.h / s;
    const scaled = drawScaled(src, (w - rw2) / 2, (h - rh2) / 2, rw2, rh2, spec.w, spec.h);
    return { canvas: scaled, usedFace: false };
  }
  const scale = spec.w / cw;
  const dx = (sx0 - cx) * scale;
  const dy = (sy0 - cy) * scale;
  const dw = sw * scale;
  const dh = sh * scale;
  const part = drawScaled(src, sx0, sy0, sw, sh, dw, dh);
  ctx.drawImage(part, Math.round(dx), Math.round(dy), part.width, part.height);
  return { canvas: out, usedFace };
}

/** A 6x4 in (1800x1200, 300 DPI) print sheet filled with true-size copies of the photo + thin cut lines. */
export function makePrintSheet(photo: HTMLCanvasElement, mmW: number, mmH: number): HTMLCanvasElement {
  const sheetW = 1800;
  const sheetH = 1200;
  const pw = Math.round((mmW / 25.4) * 300);
  const ph = Math.round((mmH / 25.4) * 300);
  const tile = drawScaled(photo, 0, 0, photo.width, photo.height, pw, ph);
  const sheet = makeCanvas(sheetW, sheetH);
  const ctx = sheet.getContext('2d')!;
  ctx.fillStyle = '#FFFFFF';
  ctx.fillRect(0, 0, sheetW, sheetH);
  const gap = 16;
  const cols = Math.max(1, Math.floor((sheetW - gap) / (pw + gap)));
  const rows = Math.max(1, Math.floor((sheetH - gap) / (ph + gap)));
  const totalW = cols * pw + (cols - 1) * gap;
  const totalH = rows * ph + (rows - 1) * gap;
  const ox = Math.round((sheetW - totalW) / 2);
  const oy = Math.round((sheetH - totalH) / 2);
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = ox + c * (pw + gap);
      const y = oy + r * (ph + gap);
      ctx.drawImage(tile, x, y);
      ctx.strokeStyle = '#C8C8C8';
      ctx.lineWidth = 1;
      ctx.strokeRect(x - 0.5, y - 0.5, pw + 1, ph + 1);
    }
  }
  return sheet;
}

// ---------------------------------------------------------------------------
// Metadata stripping that keeps the file type
// ---------------------------------------------------------------------------

/** Removes APP1(EXIF/XMP), APP2, APP13, COM from a JPEG without re-encoding - zero quality loss. */
export function stripJpegLossless(buf: ArrayBuffer): Blob | null {
  const u8 = new Uint8Array(buf);
  if (u8.length < 4 || u8[0] !== 0xff || u8[1] !== 0xd8) return null;
  const parts: Uint8Array[] = [u8.subarray(0, 2)];
  let off = 2;
  let orientation: Uint8Array | null = null;
  while (off < u8.length - 1) {
    if (u8[off] !== 0xff) {
      // not a marker - copy the rest as is
      parts.push(u8.subarray(off));
      off = u8.length;
      break;
    }
    const marker = u8[off + 1];
    if (marker === 0xda) {
      parts.push(u8.subarray(off));
      off = u8.length;
      break;
    }
    if (marker === 0xd8 || marker === 0x01 || (marker >= 0xd0 && marker <= 0xd7)) {
      parts.push(u8.subarray(off, off + 2));
      off += 2;
      continue;
    }
    const len = (u8[off + 2] << 8) | u8[off + 3];
    if (len < 2) return null;
    const end = off + 2 + len;
    const drop = marker === 0xe1 || marker === 0xe2 || marker === 0xed || marker === 0xfe || (marker >= 0xe3 && marker <= 0xef && marker !== 0xee);
    if (!drop) parts.push(u8.subarray(off, Math.min(end, u8.length)));
    off = end;
  }
  void orientation;
  return new Blob(parts as BlobPart[], { type: 'image/jpeg' });
}

/**
 * Clean a photo. JPEG -> lossless byte stripping but the orientation is baked in first if the
 * photo is rotated by EXIF (otherwise removing EXIF would turn it sideways).
 * PNG / WebP / others -> redraw at full resolution in the SAME format (transparency kept).
 */
export async function cleanMetadata(file: File | Blob, info: { width: number; height: number }): Promise<{ blob: Blob; ext: string }> {
  const type = (file.type || '').toLowerCase();
  const name = (file as File).name?.toLowerCase() || '';
  const isJpeg = type === 'image/jpeg' || /\.jpe?g$/.test(name);
  if (isJpeg) {
    const buf = await file.arrayBuffer();
    const exif = parseExif(buf.slice(0, 262144));
    const needsBake = !!exif && !!exif.orientation && exif.orientation !== 1;
    if (!needsBake) {
      const stripped = stripJpegLossless(buf);
      if (stripped) return { blob: stripped, ext: 'jpg' };
    }
    const d = await decodeBlob(file);
    const { w, h } = dimsOf(d);
    const c = makeCanvas(w, h);
    c.getContext('2d')!.drawImage(d as CanvasImageSource, 0, 0);
    releaseDrawable(d);
    const blob = await canvasToBlob(c, 'image/jpeg', 0.98);
    const clean = stripJpegLossless(await blob.arrayBuffer());
    return { blob: clean || blob, ext: 'jpg' };
  }
  const d = await decodeBlob(file);
  const { w, h } = dimsOf(d);
  const c = makeCanvas(w, h);
  c.getContext('2d')!.drawImage(d as CanvasImageSource, 0, 0);
  releaseDrawable(d);
  let mime = 'image/png';
  if (type === 'image/webp') mime = 'image/webp';
  const out = await canvasToBlob(c, mime, mime === 'image/webp' ? 1 : undefined);
  const ok = out.type === mime;
  return { blob: out, ext: ok ? extFromMime(mime) : 'png' };
}

// ---------------------------------------------------------------------------
// Own encoders: browsers cannot encode BMP / GIF through canvas
// ---------------------------------------------------------------------------
export function encodeBmp(c: HTMLCanvasElement, bg = '#FFFFFF'): Blob {
  const flat = flattenOnColor(c, bg);
  const { width: w, height: h } = flat;
  const data = flat.getContext('2d')!.getImageData(0, 0, w, h).data;
  const rowSize = Math.ceil((w * 3) / 4) * 4;
  const imgSize = rowSize * h;
  const buf = new ArrayBuffer(54 + imgSize);
  const dv = new DataView(buf);
  dv.setUint8(0, 0x42);
  dv.setUint8(1, 0x4d);
  dv.setUint32(2, 54 + imgSize, true);
  dv.setUint32(10, 54, true);
  dv.setUint32(14, 40, true);
  dv.setInt32(18, w, true);
  dv.setInt32(22, h, true);
  dv.setUint16(26, 1, true);
  dv.setUint16(28, 24, true);
  dv.setUint32(34, imgSize, true);
  dv.setInt32(38, 2835, true);
  dv.setInt32(42, 2835, true);
  const u8 = new Uint8Array(buf);
  for (let y = 0; y < h; y++) {
    const rowStart = 54 + (h - 1 - y) * rowSize;
    for (let x = 0; x < w; x++) {
      const s = (y * w + x) * 4;
      const d = rowStart + x * 3;
      u8[d] = data[s + 2];
      u8[d + 1] = data[s + 1];
      u8[d + 2] = data[s];
    }
  }
  return new Blob([buf], { type: 'image/bmp' });
}

/** Median-cut palette (up to 255 colours + 1 transparent slot). */
function buildPalette(px: Uint8ClampedArray, maxColors: number): number[][] {
  // sample at most ~60k pixels
  const step = Math.max(1, Math.floor(px.length / 4 / 60000));
  let boxes: number[][][] = [[]];
  for (let i = 0; i < px.length; i += 4 * step) {
    if (px[i + 3] < 128) continue;
    boxes[0].push([px[i], px[i + 1], px[i + 2]]);
  }
  if (!boxes[0].length) return [[0, 0, 0]];
  while (boxes.length < maxColors) {
    // split the box with the widest range
    let bi = -1;
    let best = -1;
    let ch = 0;
    boxes.forEach((b, i) => {
      if (b.length < 2) return;
      for (let k = 0; k < 3; k++) {
        let mn = 255;
        let mx = 0;
        for (const p of b) {
          if (p[k] < mn) mn = p[k];
          if (p[k] > mx) mx = p[k];
        }
        const range = (mx - mn) * Math.sqrt(b.length);
        if (range > best) {
          best = range;
          bi = i;
          ch = k;
        }
      }
    });
    if (bi < 0 || best <= 0) break;
    const b = boxes[bi].sort((a, c) => a[ch] - c[ch]);
    const mid = b.length >> 1;
    boxes.splice(bi, 1, b.slice(0, mid), b.slice(mid));
  }
  return boxes
    .filter((b) => b.length)
    .map((b) => {
      let r = 0,
        g = 0,
        bl = 0;
      for (const p of b) {
        r += p[0];
        g += p[1];
        bl += p[2];
      }
      return [Math.round(r / b.length), Math.round(g / b.length), Math.round(bl / b.length)];
    });
}

export function encodeGif(c: HTMLCanvasElement): Blob {
  const { width: w, height: h } = c;
  const px = c.getContext('2d')!.getImageData(0, 0, w, h).data;
  let hasAlpha = false;
  for (let i = 3; i < px.length; i += 4) {
    if (px[i] < 128) {
      hasAlpha = true;
      break;
    }
  }
  const pal = buildPalette(px, hasAlpha ? 255 : 256);
  const transIndex = hasAlpha ? pal.length : -1;
  const total = pal.length + (hasAlpha ? 1 : 0);
  let bits = 1;
  while (1 << bits < total) bits++;
  const palSize = 1 << bits;

  // nearest colour with small cache + Floyd-Steinberg-free (clean, no noise) mapping
  const cache = new Map<number, number>();
  const idx = new Uint8Array(w * h);
  for (let i = 0, p = 0; i < px.length; i += 4, p++) {
    if (px[i + 3] < 128) {
      idx[p] = transIndex;
      continue;
    }
    const key = ((px[i] >> 2) << 12) | ((px[i + 1] >> 2) << 6) | (px[i + 2] >> 2);
    let v = cache.get(key);
    if (v === undefined) {
      let bd = Infinity;
      v = 0;
      for (let k = 0; k < pal.length; k++) {
        const dr = pal[k][0] - px[i];
        const dg = pal[k][1] - px[i + 1];
        const db = pal[k][2] - px[i + 2];
        const d = dr * dr * 2 + dg * dg * 4 + db * db * 3;
        if (d < bd) {
          bd = d;
          v = k;
        }
      }
      cache.set(key, v);
    }
    idx[p] = v;
  }

  const out: number[] = [];
  const w16 = (n: number) => out.push(n & 255, (n >> 8) & 255);
  out.push(0x47, 0x49, 0x46, 0x38, 0x39, 0x61);
  w16(w);
  w16(h);
  out.push(0x80 | ((bits - 1) << 4) | (bits - 1), 0, 0);
  for (let i = 0; i < palSize; i++) {
    const c3 = pal[i] || [0, 0, 0];
    out.push(c3[0], c3[1], c3[2]);
  }
  if (hasAlpha) out.push(0x21, 0xf9, 4, 0x01, 0, 0, transIndex, 0);
  out.push(0x2c);
  w16(0);
  w16(0);
  w16(w);
  w16(h);
  out.push(0);
  const minCode = Math.max(2, bits);
  out.push(minCode);

  // LZW
  const clear = 1 << minCode;
  const eoi = clear + 1;
  let codeSize = minCode + 1;
  let next = eoi + 1;
  let dict = new Map<number, number>();
  const bytes: number[] = [];
  let cur = 0;
  let curBits = 0;
  const emit = (code: number) => {
    cur |= code << curBits;
    curBits += codeSize;
    while (curBits >= 8) {
      bytes.push(cur & 255);
      cur >>>= 8;
      curBits -= 8;
    }
  };
  emit(clear);
  let prefix = idx[0];
  for (let i = 1; i < idx.length; i++) {
    const k = idx[i];
    const key = (prefix << 8) | k;
    const hit = dict.get(key);
    if (hit !== undefined) {
      prefix = hit;
    } else {
      emit(prefix);
      if (next < 4096) {
        dict.set(key, next++);
        if (next > 1 << codeSize && codeSize < 12) codeSize++;
      } else {
        emit(clear);
        dict = new Map();
        next = eoi + 1;
        codeSize = minCode + 1;
      }
      prefix = k;
    }
  }
  emit(prefix);
  emit(eoi);
  if (curBits > 0) bytes.push(cur & 255);
  for (let i = 0; i < bytes.length; i += 255) {
    const chunk = bytes.slice(i, i + 255);
    out.push(chunk.length, ...chunk);
  }
  out.push(0, 0x3b);
  return new Blob([new Uint8Array(out)], { type: 'image/gif' });
}

/** Same EXIF block, but with Orientation reset to 1 (the pixels are already upright). */
export function exifWithUprightOrientation(app1: Uint8Array): Uint8Array {
  try {
    const copy = new Uint8Array(app1);
    const dv = new DataView(copy.buffer);
    const t = 10;
    const little = dv.getUint16(t) === 0x4949;
    const ifd = dv.getUint32(t + 4, little);
    const n = dv.getUint16(t + ifd, little);
    for (let i = 0; i < n; i++) {
      const e = t + ifd + 2 + i * 12;
      if (dv.getUint16(e, little) === 0x0112) dv.setUint16(e + 8, 1, little);
    }
    return copy;
  } catch {
    return app1;
  }
}

// ---------------------------------------------------------------------------
// Proper PDF writer (valid xref + trailer, binary-safe, original JPEG bytes kept)
// ---------------------------------------------------------------------------
export interface PdfImage {
  jpegBytes: Uint8Array;
  width: number;
  height: number;
  /** 1 = gray, 3 = RGB */
  comps: number;
}

/** Reads components/bit-depth/size from a JPEG header (no decoding). */
export function jpegHeader(u8: Uint8Array): { comps: number; bits: number; width: number; height: number } | null {
  if (u8.length < 4 || u8[0] !== 0xff || u8[1] !== 0xd8) return null;
  let off = 2;
  while (off < u8.length - 9) {
    if (u8[off] !== 0xff) {
      off++;
      continue;
    }
    const m = u8[off + 1];
    if (m === 0xd8 || m === 0x01 || (m >= 0xd0 && m <= 0xd7) || m === 0xff) {
      off += m === 0xff ? 1 : 2;
      continue;
    }
    const len = (u8[off + 2] << 8) | u8[off + 3];
    if (m >= 0xc0 && m <= 0xcf && m !== 0xc4 && m !== 0xc8 && m !== 0xcc) {
      return { bits: u8[off + 4], height: (u8[off + 5] << 8) | u8[off + 6], width: (u8[off + 7] << 8) | u8[off + 8], comps: u8[off + 9] };
    }
    if (len < 2) return null;
    off += 2 + len;
  }
  return null;
}

export function buildPdf(
  images: PdfImage[],
  pageSize: 'fit' | 'a4' | 'letter',
  orientation: 'auto' | 'portrait' | 'landscape',
  marginPt: number
): Blob {
  const enc = new TextEncoder();
  const chunks: Uint8Array[] = [];
  let pos = 0;
  const push = (d: Uint8Array | string) => {
    const b = typeof d === 'string' ? enc.encode(d) : d;
    chunks.push(b);
    pos += b.length;
  };
  const total = 2 + images.length * 3;
  const offsets: number[] = new Array(total + 1).fill(0);
  const obj = (id: number, dict: string, stream?: Uint8Array) => {
    offsets[id] = pos;
    push(`${id} 0 obj\n${dict}\n`);
    if (stream) {
      push('stream\n');
      push(stream);
      push('\nendstream\n');
    }
    push('endobj\n');
  };

  push(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2d, 0x31, 0x2e, 0x34, 0x0a, 0x25, 0xe2, 0xe3, 0xcf, 0xd3, 0x0a]));
  const kids = images.map((_, i) => `${5 + i * 3} 0 R`).join(' ');
  obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
  obj(2, `<< /Type /Pages /Kids [${kids}] /Count ${images.length} >>`);

  images.forEach((img, i) => {
    const imgId = 3 + i * 3;
    const contId = 4 + i * 3;
    const pageId = 5 + i * 3;
    let pageW: number;
    let pageH: number;
    if (pageSize === 'fit') {
      pageW = img.width * 0.75 + marginPt * 2;
      pageH = img.height * 0.75 + marginPt * 2;
    } else {
      pageW = pageSize === 'letter' ? 612 : 595.28;
      pageH = pageSize === 'letter' ? 792 : 841.89;
      const wantLandscape = orientation === 'landscape' || (orientation === 'auto' && img.width > img.height);
      if (wantLandscape && pageH > pageW) [pageW, pageH] = [pageH, pageW];
      if (!wantLandscape && pageW > pageH) [pageW, pageH] = [pageH, pageW];
    }
    const availW = Math.max(10, pageW - marginPt * 2);
    const availH = Math.max(10, pageH - marginPt * 2);
    const scale = Math.min(availW / img.width, availH / img.height);
    const dw = img.width * scale;
    const dh = img.height * scale;
    const dx = marginPt + (availW - dw) / 2;
    const dy = marginPt + (availH - dh) / 2;
    const cs = img.comps === 1 ? '/DeviceGray' : '/DeviceRGB';
    obj(imgId, `<< /Type /XObject /Subtype /Image /Width ${img.width} /Height ${img.height} /ColorSpace ${cs} /BitsPerComponent 8 /Filter /DCTDecode /Length ${img.jpegBytes.length} >>`, img.jpegBytes);
    const content = `q\n${dw.toFixed(2)} 0 0 ${dh.toFixed(2)} ${dx.toFixed(2)} ${dy.toFixed(2)} cm\n/Im0 Do\nQ`;
    obj(contId, `<< /Length ${content.length} >>`, enc.encode(content));
    obj(pageId, `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${pageW.toFixed(2)} ${pageH.toFixed(2)}] /Contents ${contId} 0 R /Resources << /XObject << /Im0 ${imgId} 0 R >> >> >>`);
  });

  const xrefPos = pos;
  let xref = `xref\n0 ${total + 1}\n0000000000 65535 f \n`;
  for (let id = 1; id <= total; id++) xref += `${String(offsets[id]).padStart(10, '0')} 00000 n \n`;
  push(xref + `trailer\n<< /Size ${total + 1} /Root 1 0 R >>\nstartxref\n${xrefPos}\n%%EOF\n`);
  return new Blob(chunks as BlobPart[], { type: 'application/pdf' });
}

// ---------------------------------------------------------------------------
// PDF -> images (real page rendering with pdf.js, runs locally)
// ---------------------------------------------------------------------------
export async function renderPdfPages(
  file: Blob,
  opts: { scale: number; fmt: 'png' | 'jpg' | 'webp'; maxPages: number; onProgress?: (done: number, total: number) => void }
): Promise<{ blob: Blob; page: number; w: number; h: number; totalPages: number }[]> {
  const pdfjs: any = await import('pdfjs-dist/legacy/build/pdf.mjs');
  pdfjs.GlobalWorkerOptions.workerSrc = new URL('pdfjs-dist/legacy/build/pdf.worker.min.mjs', import.meta.url).href;
  const data = new Uint8Array(await file.arrayBuffer());
  let doc: any;
  try {
    doc = await pdfjs.getDocument({ data }).promise;
  } catch (e: any) {
    if (e?.name === 'PasswordException') throw new Error('This PDF is password protected. Remove the password first, then try again.');
    throw new Error('This PDF could not be read. The file may be damaged.');
  }
  const total = doc.numPages;
  const n = Math.min(total, opts.maxPages);
  const out: { blob: Blob; page: number; w: number; h: number; totalPages: number }[] = [];
  for (let p = 1; p <= n; p++) {
    const page = await doc.getPage(p);
    const base = page.getViewport({ scale: 1 });
    let k = (opts.scale * 150) / 72; // 1x = 150 DPI, 2x = 300 DPI ...
    const maxSide = 9000; // keeps every browser inside its canvas limit
    k = Math.min(k, maxSide / Math.max(base.width, base.height));
    const vp = page.getViewport({ scale: k });
    const c = makeCanvas(vp.width, vp.height);
    const ctx = c.getContext('2d')!;
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, c.width, c.height);
    await page.render({ canvasContext: ctx, viewport: vp, canvas: c }).promise;
    const { blob } = await encodeCanvas(c, opts.fmt, 0.95);
    out.push({ blob, page: p, w: c.width, h: c.height, totalPages: total });
    page.cleanup?.();
    opts.onProgress?.(p, n);
    await new Promise((r) => setTimeout(r, 0));
  }
  try {
    doc.destroy?.();
  } catch {
    /* ignore */
  }
  return out;
}

// ---------------------------------------------------------------------------
// Favicon / app icon set
// ---------------------------------------------------------------------------
export async function makeIconPngs(src: Drawable, sizes: number[], opaqueBg?: string): Promise<Map<number, Uint8Array>> {
  const { w, h } = dimsOf(src);
  const ar = w / h;
  const nearSquare = Math.abs(ar - 1) < 0.12;
  const out = new Map<number, Uint8Array>();
  // one big square master, then high-quality step-down for every size
  const M = 1024;
  let master: HTMLCanvasElement;
  if (nearSquare) {
    const s = Math.min(w, h);
    master = drawScaled(src, (w - s) / 2, (h - s) / 2, s, s, M, M);
  } else {
    const k = Math.min(M / w, M / h);
    const dw = Math.round(w * k);
    const dh = Math.round(h * k);
    const part = drawScaled(src, 0, 0, w, h, dw, dh);
    master = makeCanvas(M, M);
    master.getContext('2d')!.drawImage(part, Math.round((M - dw) / 2), Math.round((M - dh) / 2));
  }
  for (const s of sizes) {
    let c = drawScaled(master, 0, 0, M, M, s, s);
    if (opaqueBg) c = flattenOnColor(c, opaqueBg);
    out.set(s, new Uint8Array(await (await canvasToBlob(c, 'image/png')).arrayBuffer()));
  }
  return out;
}

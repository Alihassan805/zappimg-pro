/** Ads-free build: no direct link, no ad scripts. Kept as a no-op so the rest of the code needs no changes. */
export const DIRECT_LINK = '';
export const DIRECT_LINK_GAP_MS = 0;
export function openDirectLinkOnce(): void {
  /* intentionally empty */
}
